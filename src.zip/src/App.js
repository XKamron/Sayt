import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from "./pages/Home";
import Konstitutsiya from './pages/Kons';
import Kodeks from './pages/Kodeks'; 
import Error from './pages/Error';
import Asosiy from './pages/Asosiy';
import Parent from './pages/Parent';
import MaktabKorsatkichlari from './pages/Maktab_korsatkichlari';
import SavolJavob from './pages/Savol_Javob';
import Vazir from './pages/Vazir';
import Prezident_Farmonlari from './pages/Prezident_Farmonlari';
import Vazir_buyruqlari from './pages/Vazir_buyruqlari';
import Adliya_Hujjatlar from './pages/Adliya_Hujjatlar';
import Rahbariyat from './pages/Rahbariyat';
import Xodimlar from './pages/Xodimlar';
import Bmsm_hujjatlar from './pages/Bmsm_hujjatlar';
import Lokal_Hujjatlar from './pages/Lokal_Hujjatlar';
import Talim_togrisida_qonun from './pages/Talim_togrisida_qonun';
import Aholini_ish_bilan_taminlash from './pages/Aholini_ish_bilan_taminlash';
import Bola_huquqlari from './pages/Bola_huquqlari';
import Jismoniy_yuridik_shaxs from './pages/Jismoniy_yuridik_shaxs'; 
import Kasaba_uyushmasi from './pages/Kasaba_uyushmasi';
import Madaniy_Faoliyat from './pages/Madaniy_Faoliyat';
import YoshlargaOid from './pages/YoshlargaOid';
import Mehnat_muhofaza from './pages/Mehnat_muhofaza';
import Nogironligi_b_l_shaxs from './pages/Nogironligi_b_l_shaxs';
import Shaxsga_doir from './pages/Shaxsga_doir';
import Aktorlik_sanati from './pages/Vazirlar mahkamasi qarori/Aktorlik_sanati';
import Bolalarmusiqa_maktabi from './pages/Vazirlar mahkamasi qarori/Bolalarmusiqa_maktabi';
import Bakalavariat from './pages/Vazirlar mahkamasi qarori/Bakalavariat';
import Ixtisos_maktab from './pages/Vazirlar mahkamasi qarori/Ixtisos_maktab'
import Konservatoriya from './pages/Vazirlar mahkamasi qarori/Konservatoriya'
import Atestatsiya from './pages/Vazirlar mahkamasi qarori/Atestatsiya'
import Maktabgacha from './pages/Vazirlar mahkamasi qarori/Maktabgacha'
import Madaniyat_vazirligi from './pages/Vazirlar mahkamasi qarori/Madaniyat_vazirligi'
import Odob_axloq from './pages/Vazirlar mahkamasi qarori/Odob_axloq'
import Madaniyat from './pages/Vazirlar mahkamasi qarori/Madaniyat'
import Bolalar_musiqa from './pages/Prezidentning farmonlari va qarorlari/Bolalar_musiqa'
import Pedagogiga_yonalishi from './pages/Prezidentning farmonlari va qarorlari/Pedagogiga_yonalishi'
import Maqom_sanati from './pages/Prezidentning farmonlari va qarorlari/Maqom_sanati'
import Baxchichilik_sanati from './pages/Prezidentning farmonlari va qarorlari/Baxchichilik_sanati'
import Korrupsiyaga_qarshi from './pages/Prezidentning farmonlari va qarorlari/Korrupsiyaga_qarshi'
import Musiqa_maktablari from './pages/Prezidentning farmonlari va qarorlari/Musiqa_maktablari'
import Madaniyat_vazirligi_faoliyati from './pages/Prezidentning farmonlari va qarorlari/Madaniyat_vazirligi_faoliyati'
import Madaniyat_sanat_sohasi from './pages/Prezidentning farmonlari va qarorlari/Madaniyat_sanat_sohasi'
import Madaniyat_sanatni_rivojlantirish from './pages/Prezidentning farmonlari va qarorlari/Madaniyat_sanatni_rivojlantirish'
import Madaniyat_sanat_sohasi_yenada_rivojlantirish from './pages/Prezidentning farmonlari va qarorlari/Madaniyat_sanat_sohasi_yenada_rivojlantirish'
import Bmsm_xodimlari from './pages/Bmsm_xodimlari'
import Malaka_tavsiflari from './pages/Malaka_tavsiflari'
import Oquvchilar_xavfsizligi from './pages/Oquvchilar_xavfsizligi'
import Mehnat_muxofazasi from './pages/Mehnat_muxofazasi'
import Mehnatni_muhofaza_qilish from './pages/Mehnatni_Muhofaza_qilish'
import Oquv_dasturlari from './pages/Oquv_dasturlari'
import Tanlovlar from './pages/Tanlovlar'
import Oquvjarayonlari_hujjatlar from './pages/Oquvjarayonlari_hujjatlar'
function App() {
  return (
    <Router>
      <Switch>
        <Route exact path="/" component={Home} />
        <Route path="/kons" component={Konstitutsiya} />
        <Route path="/kodeks" component={Kodeks} /> {/* Страница Kodeks */}
        <Route path="/asosiy" component={Asosiy} />
        <Route path="/parent" component={Parent} />
        <Route path="/maktab_korsatkichlari" component={MaktabKorsatkichlari} />
        <Route path="/savol_javob" component={SavolJavob} />
        <Route path="/vazir" component={Vazir} />
        <Route path="/prezident_farmonlari" component={Prezident_Farmonlari} />
        <Route path="/vazir_buyruqlari" component={Vazir_buyruqlari} />
        <Route path="/adliya_hujjatlar" component={Adliya_Hujjatlar} />
        <Route path="/rahbariyat" component={Rahbariyat} />
        <Route path="/xodimlar" component={Xodimlar} />
        <Route path="/bmsm_hujjatlar" component={Bmsm_hujjatlar} />
        <Route path="/lokal_hujjatlar" component={Lokal_Hujjatlar} />
        <Route path="/talim_togrisida_qonun" component={Talim_togrisida_qonun} />
        <Route path="/aholini_ish_bilan_taminlash" component={Aholini_ish_bilan_taminlash} />
        <Route path="/bola_huquqlari" component={Bola_huquqlari} />
        <Route path="/jismoniy_yuridik_shaxs" component={Jismoniy_yuridik_shaxs} />
        <Route path="/kasaba_uyushmasi" component={Kasaba_uyushmasi} />
        <Route path="/korrupsiyaga_qarshi" component={Korrupsiyaga_qarshi} />
        <Route path="/madaniy_faoliyat" component={Madaniy_Faoliyat} />
        <Route path="/yoshlargaOid" component={YoshlargaOid} />
        <Route path="/mehnat_muhofaza" component={Mehnat_muhofaza} />
        <Route path="/nogironligi_b_l_shaxs" component={Nogironligi_b_l_shaxs} />
        <Route path="/shaxsga_doir" component={Shaxsga_doir} />
        <Route path="/aktorlik_sanati" component={Aktorlik_sanati} />
        <Route path="/bolalarmusiqa_maktabi" component={Bolalarmusiqa_maktabi} />
        <Route path="/bakalavariat" component={Bakalavariat} />
        <Route path="/ixtisos_maktab" component={Ixtisos_maktab} />
        <Route path="/konservatoriya" component={Konservatoriya} />
        <Route path="/atestatsiya" component={Atestatsiya} />
        <Route path="/maktabgacha" component={Maktabgacha} />
        <Route path="/madaniyat_vazirligi" component={Madaniyat_vazirligi} />
        <Route path="/odob_axloq" component={Odob_axloq} />
        <Route path="/madaniyat" component={Madaniyat} />
        <Route path="/bolalar_musiqa" component={Bolalar_musiqa} />
        <Route path="/pedagogiga_yonalishi" component={Pedagogiga_yonalishi} />
        <Route path="/maqom_sanati" component={Maqom_sanati} />
        <Route path="/baxchichilik_sanati" component={Baxchichilik_sanati} />
        <Route path="/korrupsiyaga_qarshi" component={Korrupsiyaga_qarshi} />
        <Route path="/musiqa_maktablari" component={Musiqa_maktablari} />
        <Route path="/madaniyat_vazirligi_faoliyati" component={Madaniyat_vazirligi_faoliyati} />
        <Route path="/madaniyat_sanat_sohasi" component={Madaniyat_sanat_sohasi} />
        <Route path="/madaniyat_sanatni_rivojlantirish" component={Madaniyat_sanatni_rivojlantirish} />
        <Route path="/madaniyat_sanat_sohasi_yenada_rivojlantirish" component={Madaniyat_sanat_sohasi_yenada_rivojlantirish} />
        <Route path="/bmsm_xodimlari" component={Bmsm_xodimlari} />
        <Route path="/malaka_tavsiflari" component={Malaka_tavsiflari} />
        <Route path="/oquvchilar_xavfsizligi" component={Oquvchilar_xavfsizligi} />
        <Route path="/mehnat_muxofazasi" component={Mehnat_muxofazasi} />
        <Route path="/mehnatni_muhofaza_qilish" component={Mehnatni_muhofaza_qilish} />
        <Route path="/oquv_dasturlari" component={Oquv_dasturlari} />
        <Route path="/Tanlovlar" component={Tanlovlar} />
        <Route path="/Oquvjarayonlari_hujjatlar" component={Oquvjarayonlari_hujjatlar} />
        <Route component={Error} />
      </Switch>
    </Router>
  );
}

export default App;

