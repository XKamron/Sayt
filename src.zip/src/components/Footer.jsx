import React, { useEffect } from 'react';
import { logo } from '../img';
import { 
  FaPhone, FaEnvelope, FaMapMarkerAlt, FaClock, 
  FaFileAlt, FaTelegram 
} from 'react-icons/fa';
import AOS from 'aos';
import 'aos/dist/aos.css';

const Footer = () => {
  useEffect(() => {
    AOS.init({ duration: 800, once: true });
  }, []);

  return (
    <footer className="bg-sky-900 text-white py-12 font-[Poppins]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          
          {/* Logo & Description */}
          <div className="flex flex-col items-center md:items-start" data-aos="fade-up">
            <img src={logo} alt="Logo" className="w-32 mb-4" />
            <p className="text-center md:text-left text-sm opacity-80 leading-relaxed">
              Toshkent shahar Chilonzor tumani 6-son BMSM
            </p>
          </div>

          {/* Address */}
          <div className="text-center md:text-left" data-aos="fade-up" data-aos-delay="100">
            <h3 className="text-lg font-semibold mb-4">Manzil</h3>
            <div className="space-y-3">
              <p className="flex items-start text-sm opacity-90 hover:opacity-100 transition">
                <FaMapMarkerAlt className="mt-1 mr-2 text-sky-300" />
                100115 Toshkent shahar, Chilonzor tumani, 2-mavze, 20-uy
              </p>
              <p className="flex items-center text-sm opacity-90 hover:opacity-100 transition">
                <FaClock className="mr-2 text-sky-300" />
                Ish kuni tartibi: Dushanba - Shanba, 08:00 - 18:00
              </p>
            </div>
          </div>

          {/* Contact */}
          <div className="text-center md:text-left" data-aos="fade-up" data-aos-delay="200">
            <h3 className="text-lg font-semibold mb-4">Aloqa</h3>
            <div className="space-y-3">
              <p className="flex items-center text-sm hover:text-sky-300 transition">
                <FaPhone className="mr-2" />
                <a href="tel:+998712770085">+998 71 277-00-85</a>
              </p>
              <p className="flex items-center text-sm hover:text-sky-300 transition">
                <FaEnvelope className="mr-2" />
                <a href="mailto:6bmsmtoshkent.uz@umail.uz">6bmsmtoshkent.uz@umail.uz</a>
              </p>
              <p className="flex items-center text-sm hover:text-sky-300 transition">
                <FaTelegram className="mr-2" />
                <a href="https://t.me/bmsm6" target="_blank" rel="noopener noreferrer">
                  Telegram orqali bog'lanish
                </a>
              </p>
            </div>
          </div>

          {/* Documents */}
          <div className="text-center md:text-left" data-aos="fade-up" data-aos-delay="300">
            <h3 className="text-lg font-semibold mb-4">Hujjatlar</h3>
            <div className="space-y-2">
              <a 
                href="/files/Shartnoma_namunasi.pdf" 
                className="flex items-center text-sm hover:text-sky-300 transition"
                target="_blank"
                rel="noopener noreferrer"
              >
                <FaFileAlt className="mr-2" />
                Shartnoma va arizalar namunalari
              </a>
              <a href="#" className="block text-sm hover:text-sky-300 transition">Prezident.uz</a>
              <a href="#" className="block text-sm hover:text-sky-300 transition">Gov.uz</a>
              <a href="#" className="block text-sm hover:text-sky-300 transition">Madaniyat vazirligi</a>
            </div>
          </div>

        </div>

        {/* Copyright */}
        <div className="border-t border-sky-700 mt-12 pt-6 text-center">
          <p className="text-sm opacity-80">
            &copy; {new Date().getFullYear()} Toshkent shahar Chilonzor tumani 6-son BMSM. 
            Barcha huquqlar himoyalangan.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
