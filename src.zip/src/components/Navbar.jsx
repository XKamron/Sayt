import React, { useState, useEffect, useCallback } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FaTimes, FaBars, FaChevronDown, FaChevronUp } from 'react-icons/fa';
import { logo } from '../img';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState(null);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  // Scroll detection
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close menu on route change
  useEffect(() => {
    setIsMenuOpen(false);
    setOpenDropdown(null);
  }, [location]);

  // Disable background scroll when menu is open
  useEffect(() => {
    if (isMenuOpen) {
      document.documentElement.style.overflow = 'hidden';
      document.body.style.overflow = 'hidden';
    } else {
      document.documentElement.style.overflow = '';
      document.body.style.overflow = '';
    }
    return () => {
      document.documentElement.style.overflow = '';
      document.body.style.overflow = '';
    };
  }, [isMenuOpen]);

  const toggleMenu = useCallback(() => {
    setIsMenuOpen(prev => !prev);
    setOpenDropdown(null);
  }, []);

  const toggleDropdown = useCallback((index) => {
    setOpenDropdown(prev => (prev === index ? null : index));
  }, []);

  const navLinks = [
    {
      to: '/',
      text: 'Bosh sahifa',
      children: [
        { to: '/asosiy', text: 'Asosiy ma`lumotlar' },
        { to: '/parent', text: 'Ota-onalar sahifasi' },
        { to: '/maktab_korsatkichlari', text: 'Maktab ko`rsatkichlari' },
        { to: '/savol_javob', text: 'Savol bering - javob beramiz' },
      ],
    },
    {
      text: 'Me’yoriy-huquqiy hujjatlar',
      children: [
        { to: '/kons', text: 'O‘zbekiston Respublikasi Konstitutsiyasi' },
        { to: '/kodeks', text: 'O‘zbekiston Respublikasi Kodekslari va Qonunlari' },
        { to: '/vazir', text: 'O‘zbekiston Respublikasi Vazirlar Mahkamasining qarorlari' },
        { to: '/prezident_farmonlari', text: 'O‘zbekiston Respublikasi Prezidentining farmonlari va qarorlari' },
        { to: '/vazir_buyruqlari', text: 'O‘zbekiston Respublikasi Madaniyat vazirining buyruqlari' },
        { to: '/adliya_hujjatlar', text: 'O‘zbekiston Respublikasi Adliya vazirligidan ro‘yxatdan o‘tgan hujjatlar' },
      ],
    },
    {
      to: '/bmst',
      text: 'BMSM to‘g‘risida ma’lumotlar',
      children: [
        { to: '/rahbariyat', text: 'Rahbariyat' },
        { to: '/xodimlar', text: 'Pedagoglar' },
        { to: '/bmsm_hujjatlar', text: 'Hujjatlar' },
        { to: '/lokal_hujjatlar', text: 'Lokal hujjatlar' },
        { to: '/bmsm_xodimlari', text: 'BMSM xodimlarining odob-axloq qoidalari' },
        { to: '/malaka_tavsiflari', text: 'Malaka tavsiflari' },
        { to: '/oquvchilar_xavfsizligi', text: 'Oquvchilar xavfsizligi' },
        { to: '/mehnat_muxofazasi', text: 'Mehnat muxofazasi' },
        { to: '/Bo‘sh ish o‘rinlari', text: 'Bo‘sh ish o‘rinlari' },
      ],
    },
    {
      text: 'O‘quv jarayonlari',
      children: [
        { to: '/Oquv_dasturlari', text: 'O‘quv dasturlari' },
        { to: '/Oquvjarayonlari_hujjatlar', text: 'Hujjatlar' },
        { to: '/Tanlovlar', text: 'Tanlovlar, festivallar' },
        { to: '/adliya_hujjatlar', text: 'BMSM pedagogik kengashi' },
      ],
    },
    { to: '/galereya', text: 'Galereya' },
    { to: '/aloqa', text: 'Aloqa' },
  ];

  const isActiveLink = (linkTo) => {
    if (linkTo === '/' && location.pathname === '/') return true;
    if (linkTo !== '/' && location.pathname.startsWith(linkTo)) return true;
    return false;
  };

  const renderDesktopNavLinks = () =>
    navLinks.map((link, index) => {
      const hasChildren = link.children && link.children.length > 0;
      const isActive = link.to && isActiveLink(link.to);

      if (hasChildren) {
        return (
          <div key={index} className="relative group">
            <div
              className={`cursor-pointer px-3 xl:px-4 py-2 rounded-lg transition-all duration-200 font-medium text-sm xl:text-base flex items-center space-x-1 ${
                isActive
                  ? 'text-sky-700 bg-sky-50'
                  : 'text-sky-900 hover:text-sky-700 hover:bg-sky-50'
              }`}
            >
              <span>{link.text}</span>
              <FaChevronDown className="text-xs transition-transform group-hover:rotate-180" />
            </div>
            <div className="absolute left-0 top-full mt-2 min-w-[280px] bg-white shadow-xl rounded-lg border border-sky-100 z-[99999]
              opacity-0 invisible group-hover:opacity-100 group-hover:visible
              transition-all duration-300 ease-out transform translate-y-2 group-hover:translate-y-0">
              <div className="py-2">
                {link.children.map((child, i) => (
                  <Link
                    key={i}
                    to={child.to}
                    className={`block px-4 py-3 text-sm transition-colors duration-200 ${
                      isActiveLink(child.to)
                        ? 'text-sky-700 bg-sky-50 border-r-2 border-sky-700'
                        : 'text-gray-700 hover:text-sky-700 hover:bg-sky-50'
                    }`}
                  >
                    {child.text}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        );
      }

      return (
        <Link
          key={index}
          to={link.to}
          className={`px-3 xl:px-4 py-2 rounded-lg transition-all duration-200 font-medium text-sm xl:text-base ${
            isActive
              ? 'text-sky-700 bg-sky-50'
              : 'text-sky-900 hover:text-sky-700 hover:bg-sky-50'
          }`}
        >
          {link.text}
        </Link>
      );
    });

  const renderMobileNavLinks = () =>
    navLinks.map((link, index) => {
      const hasChildren = link.children && link.children.length > 0;
      const isActive = link.to && isActiveLink(link.to);
      const isDropdownOpen = openDropdown === index;

      if (hasChildren) {
        return (
          <div key={index} className="border-b border-sky-700/20">
            <div
              className={`flex items-center justify-between px-4 py-4 cursor-pointer transition-colors duration-200 ${
                isActive ? 'text-sky-200 bg-sky-700/20' : 'text-white hover:text-sky-200 hover:bg-sky-700/10'
              }`}
              onClick={() => toggleDropdown(index)}
            >
              <span className="font-medium">{link.text}</span>
              {isDropdownOpen ? <FaChevronUp className="text-sm" /> : <FaChevronDown className="text-sm" />}
            </div>
            <div
              className={`overflow-hidden transition-all duration-300 ease-in-out ${
                isDropdownOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
              }`}
            >
              <div className="bg-sky-700/10">
                {link.children.map((child, i) => (
                  <Link
                    key={i}
                    to={child.to}
                    onClick={() => {
                      setIsMenuOpen(false);
                      setOpenDropdown(null);
                    }}
                    className={`block px-8 py-3 text-sm transition-colors duration-200 ${
                      isActiveLink(child.to)
                        ? 'text-sky-200 bg-sky-700/20 border-l-2 border-sky-200'
                        : 'text-gray-200 hover:text-white hover:bg-sky-700/20'
                    }`}
                  >
                    {child.text}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        );
      }

      return (
        <div key={index} className="border-b border-sky-700/20">
          <Link
            to={link.to}
            onClick={() => setIsMenuOpen(false)}
            className={`block px-4 py-4 font-medium transition-colors duration-200 ${
              isActive
                ? 'text-sky-200 bg-sky-700/20 border-l-2 border-sky-200'
                : 'text-white hover:text-sky-200 hover:bg-sky-700/10'
            }`}
          >
            {link.text}
          </Link>
        </div>
      );
    });

  return (
    <nav className={`sticky top-0 z-50 transition-all duration-300 ${
      scrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-white shadow-md'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3 flex-shrink-0">
            <img
              src={logo}
              alt="To'xtasin Jalilov nomidagi 6-son bolalar musiqa va san'at maktabi"
              className="h-10 w-auto sm:h-12 lg:h-14 transition-all duration-200 hover:scale-105"
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-1 xl:space-x-2 bg-gradient-to-r from-sky-50 to-blue-50 rounded-full px-6 py-2 border border-sky-200">
            {renderDesktopNavLinks()}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="menu-toggle lg:hidden p-2 rounded-lg text-sky-900 hover:text-sky-700 hover:bg-sky-50 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2"
          >
            {isMenuOpen ? <FaTimes className="text-xl" /> : <FaBars className="text-xl" />}
          </button>
        </div>
      </div>

      {/* Overlay */}
      {isMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-[99998] lg:hidden transition-opacity duration-300"
          onClick={() => setIsMenuOpen(false)}
        />
      )}

      {/* Mobile Menu */}
      <div
        className={`mobile-menu fixed top-0 right-0 bottom-0 w-80 max-w-[85vw] 
        bg-gradient-to-b from-sky-900 to-sky-800 
        z-[99999] lg:hidden transform transition-transform duration-300 ease-in-out
        ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'} h-screen overflow-y-auto`}
      >
        <div className="flex items-center justify-between p-4 border-b border-sky-700/30">
          <div className="flex items-center space-x-3">
            <img src={logo} alt="Logo" className="h-8 w-auto" />
            <span className="text-white font-semibold text-sm">Menyu</span>
          </div>
          <button
            onClick={() => setIsMenuOpen(false)}
            className="p-2 rounded-lg text-white hover:text-sky-200 hover:bg-sky-700/30 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-sky-400"
          >
            <FaTimes className="text-lg" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-4">{renderMobileNavLinks()}</div>
      </div>
    </nav>
  );
};

export default Navbar;
