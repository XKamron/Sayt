import React from 'react'

const Numbers = () => {
    return (
        <div className='bg-[#FFF6EB]'>
            <div className='text-center p-5'>
                <p className='text-[17px] text-[#76B1E8]'>Maktab faoliyati</p>
                <p className='text-[25px] text-[#00486C] font-semibold'>Maktab ko‘rsatkichlari</p>
            </div>

            <div>
                <div className='flex justify-between items-center py-8 px-[8rem]'>
                    <div>
                        <div className='block text-center'>
                            <p className='text-[18px] text-[#76B1E8]'>Maktab tashkil etilgan yil</p>
                            <h1 className='font-extrabold text-[4rem] text-[#00486C]'>1970</h1>
                        </div>
                    </div>
                    <div>
                        <div className='block text-center'>
                            <p className='text-[18px] text-[#76B1E8]'>Maktab tashkil etilgan yil</p>
                            <h1 className='font-extrabold text-[4rem] text-[#00486C]'>1970</h1>
                        </div>
                    </div>
                    <div>
                        <div className='block text-center'>
                            <p className='text-[18px] text-[#76B1E8]'>Maktab tashkil etilgan yil</p>
                            <h1 className='font-extrabold text-[4rem] text-[#00486C]'>1970</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Numbers;