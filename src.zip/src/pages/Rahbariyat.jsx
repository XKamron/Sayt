import React, { useState } from 'react';
import Header from '../components/Header';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Direktor from '../img/Direktor_22.jpg';
import Zavuch from '../img/Zavuch.jpg';

const people = [
  {
    id: 1,
    firstName: 'Karimov',
    lastName: 'Komiljon Muxammatqulovich',
    position: '6-son bolalar musiqa va san’at maktabi direktori',
    phone: '+998 71 277-00-85',
    photo: Direktor,
    workTime: 'Dushanba - 10.00 - 12.00,Chorshanba - 10.00 - 12.00',
    education: [
      { place: 'Toshkent davlat madaniyat instituti talabasi', year: '2008-2012' },
    ],
    experience: [
      { job: 'Toshkent shaxar Yunusobod tumani Xamid Olimjon nomli madaniyat uyi qoshidagi “Yulduz” estrada guruxi rahbari',  year: '2012–2013 ' },
      { job: 'Toshkent shaxar Yunusobod tumani Xamid Olimjon nomli madaniyat uyi badiiy raxbari', year: '2013–2014' },
    ],
    current: 'Rahbariyatni boshqarish, strategik qarorlar qabul qilish.',
  },
  {
    id: 2,
    firstName: 'Saydullayev',
    lastName: 'Saidakbar Soibjon o‘g‘li',
    position: '6-sonli bolalar musiqa va san’at maktabi direktorining o‘quv ishlari va madaniy-ma‘rifiy ishlar bo‘yicha o‘rinbosari',
    phone: '+998 71 277-00-85',
    photo: Zavuch,
    workTime: 'Seshanba - 14.00 - 16.00,Payshanba - 10.00 - 12.00',
    education: [
      { place: 'Samarqand Iqtisodiyot Instituti', degree: 'Bakalavr', year: '2012-2016' },
    ],
    experience: [
      { job: 'Hisobchi', place: 'Samarqand banki', year: '2016-2019' },
    ],
    current: 'Moliyaviy hisobotlar va byudjetni nazorat qilish.',
  },
];

const Rahbariyat = () => {
  const [openId, setOpenId] = useState(null);

  const handleDropdown = (id) => {
    setOpenId(openId === id ? null : id);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FCFF]">
      <Header />
      <Navbar />
      <main className="flex-1 px-4 md:px-16 py-8">
        <h1 className="text-sky-900 text-2xl uppercase md:text-3xl font-semibold text-center mb-8">
        Maktab ma’muriyati
        </h1>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {people.map(person => (
            <div
              key={person.id}
              className="bg-white shadow-md rounded-xl p-6 flex flex-col justify-between hover:shadow-lg transition duration-200"
            >
              <div>
                <img
                  src={person.photo}
                  alt={`${person.firstName} ${person.lastName}`}
                  className="w-32 h-32 object-cover rounded-full mx-auto mb-4 border-4 border-sky-200"
                />
                <p className="text-sky-900 text-xl font-bold mb-2">
                  {person.firstName} {person.lastName}
                </p>
                <p className="text-blue-700 font-semibold mb-1">{person.position}</p>
                <p className="text-gray-700 mb-1">Telefon: <span className="font-medium">{person.phone}</span></p>
                <p className="text-gray-700 mb-3">Ish vaqti: <span className="font-medium">{person.workTime}</span></p>
                <button
                  onClick={() => handleDropdown(person.id)}
                  className="mb-3 px-4 py-2 bg-sky-900 text-white rounded-lg font-semibold hover:bg-blue-700 transition"
                >
                  Batafsil
                </button>
                {openId === person.id && (
                  <div className="bg-blue-50 rounded-lg p-4 mt-2 text-sm">
                    <div className="mb-2">
                      <span className="font-semibold">Ta’lim:</span>
                      <ul className="list-disc ml-5">
                        {person.education.map((edu, idx) => (
                          <li key={idx}>
                            {edu.place}, {edu.degree} ({edu.year})
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="mb-2">
                      <span className="font-semibold">Ish tajribasi:</span>
                      <ul className="list-disc ml-5">
                        {person.experience.map((exp, idx) => (
                          <li key={idx}>
                            {exp.job} – {exp.place} ({exp.year})
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <span className="font-semibold">Hozirgi faoliyati:</span>
                      <p>{person.current}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Rahbariyat;