import React from 'react';
import Header from '../components/Header';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import {
  Ukuvchi_sinf,
  Ukuvchi_yunalish,
  Pedagog_staj,
  Pedagog_yunalish,
} from '../img';

const cardData = [
  {
    label: "Ta’lim olayotgan o‘quvchilarning sinflar bo‘yicha taqsimoti",
    img: Ukuvchi_sinf,
    alt: "Sinflar bo‘yicha o‘quvchilar taqsimoti diagrammasi",
    aria: 'O‘quvchi sinf taqsimoti grafigi',
  },
  {
    label: "Ta’lim olayotgan o‘quvchilarning yo‘nalishlar bo‘yicha taqsimoti",
    img: Ukuvchi_yunalish,
    alt: "Yo‘nalishlar bo‘yicha o‘quvchilar taqsimoti diagrammasi",
    aria: 'O‘quvchi yo‘nalish taqsimoti grafigi',
  },
  {
    label: "Pedagoglarning maktabdagi ish staji",
    img: Pedagog_staj,
    alt: "Pedagoglarning ish staji taqsimoti diagrammasi",
    aria: 'Pedagog staji taqsimoti grafigi',
  },
  {
    label: "Pedagoglarning yo‘nalishlar bo‘yicha taqsimoti",
    img: Pedagog_yunalish,
    alt: "Pedagoglarning yo‘nalishlar bo‘yicha taqsimoti diagrammasi",
    aria: 'Pedagog yo‘nalish taqsimoti grafigi',
  },
];

const MaktabKorsatkichlari = () => {
  return (
    <div className="bg-[#F9F9F9] min-h-screen flex flex-col">
      <Header />
      <Navbar />
      <main className="flex-1 w-full">
        <section className="text-center mt-8 mb-6 px-2">
          <h1 className="text-[#77572f] text-lg sm:text-xl font-bold mb-2 tracking-wide">Maktab faoliyati</h1>
          <h2 className="text-2xl sm:text-3xl md:text-4xl text-blue-950 font-extrabold drop-shadow-md">Maktab ko‘rsatkichlari</h2>
        </section>
        <section
          aria-label="Maktab ko‘rsatkichlari kartalari"
          className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6 md:gap-8 px-2 sm:px-6 lg:px-16 xl:px-32 mb-10"
        >
          {cardData.map((card, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col items-center p-4 sm:p-6 h-full border border-cyan-100 focus-within:ring-2 focus-within:ring-sky-500"
              tabIndex={0}
              aria-label={card.aria}
            >
              <p className="mb-4 text-base sm:text-lg text-center font-semibold text-sky-900">
                {card.label}
              </p>
              <img
                src={card.img}
                alt={card.alt}
                loading="lazy"
                className="w-full max-w-[280px] sm:max-w-[320px] md:max-w-[340px] xl:max-w-[360px] rounded-lg object-contain aspect-video border border-cyan-50 shadow-sm transition-transform duration-200 hover:scale-105 focus:scale-105"
              />
            </div>
          ))}
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default MaktabKorsatkichlari;