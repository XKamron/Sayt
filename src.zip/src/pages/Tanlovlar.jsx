import React from 'react';
import Header from '../components/Header';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const Tanlovlar = () => {
  // PDF data
  const competitions = [
    { 
      name: "1. M. Qori-Yoqubov nomidagi Respublika tanlovini tashkil etish va o‘tkazish tartibi to‘g‘risida Nizom", 
      file: "/files/Konkurs_Qoriyoqubov.pdf" 
    },
    { 
      name: "2. Bolalar musiqa va san’at maktablari o‘quvchilarining san’at yo‘nalishi bo‘yicha Respublika tanlovi dasturi va shartlari", 
      file: "/files/Konkurs_Sanat_yunalishi.pdf" 
    },
    { 
      name: "3. “Xalq cholg‘ulari ijrochilari” respublika tanlovining umumiy talablari, shartli asoslari va ijro dasturi", 
      file: "/files/Konkurs_Xalq_cholgulari.pdf" 
    },
    { 
      name: "4. “Yulduzcha” bolalar ijodiyoti televizion tanlovini tashkil etish va o‘tkazish tartibi to‘g‘risida Nizom", 
      file: "/files/Konkurs_Yulduzcha_tanlovi.pdf" 
    },
    { 
      name: "5. Orkestr, ansambl va ijodiy jamoalarining respublika ko‘rik tanlovi shartlari va dasturi", 
      file: "/files/Konkurs_Ansambllar.pdf" 
    },
    { 
      name: "6. Akademik va estrada ijrochiligi respublika tanlovi shartlari va dasturi", 
      file: "/files/Konkurs_Akademik_va_estrada_ijrochiligi_tanlov.pdf" 
    },
    { 
      name: "7. “Botir Zokirov sanʼati davomchilari” respublika ko‘rik-tanlovini tashkil etish va o‘tkazish to‘g‘risida Nizom", 
      file: "/files/Konkurs_Botir_Zokirov.pdf" 
    },
    { 
      name: "8. “Kamalak yulduzlari” bolalar ijodiyoti festivali Nizomi", 
      file: "/files/Konkurs_Kamalak_yulduzlari.pdf" 
    },
    { 
      name: "9. “Qalb” respublika iqtidorli yosh ijrochilari onlayn tanlovi", 
      file: "/files/Konkurs_Qalb.pdf" 
    },
    { 
      name: "10. “Sanʼatim senga, obod yurtim!” ijodiy ko‘rik-tanlovi Nizomi", 
      file: "/files/Konkurs_Sanatim_senga_obod_yurtim.pdf" 
    },
    { 
      name: "11. “Zarbchi” respublika zarbli cholg‘ular yosh ijrochilari tanlovini o‘tkazish tartibi", 
      file: "/files/Konkurs_Zarbchi.pdf" 
    },
    { 
      name: "12. “Yosh havaskorlar” amaliy sanʼat ko‘rik-tanlovini o‘tkazish tartibi", 
      file: "/files/Konkurs_Yosh_havoskarlar.pdf" 
    },
    { 
      name: "13. “Yoshlar raqs” festivalini o‘tkazish tartibi", 
      file: "/files/Konkurs_Yoshlar_raqs.pdf" 
    },
    { 
      name: "14. “Sanʼat sehri” musiqa va sanʼat tanlovini tashkil etish va o‘tkazish tartibi", 
      file: "/files/Konkurs_Sanat_sehri.pdf" 
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <Navbar />

      <main className="flex-grow container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">
        Respublika tanlovlari va festivallarini o‘tkazish
        nizomlari, tartiblari va shartlari
        </h1>

        <div className="bg-white rounded-xl shadow-md p-6 md:p-10">
          <ul className="space-y-4">
            {competitions.map((item, index) => (
              <li key={index} className="border-b pb-3 last:border-none">
                <a
                  href={item.file}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline text-sm md:text-base transition"
                >
                  {item.name}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Tanlovlar;
