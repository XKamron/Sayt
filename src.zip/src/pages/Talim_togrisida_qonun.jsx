import React, { useState } from 'react';
import Tabs from '../components/Tabs';
import Header from '../components/Header';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const Talim_togrisida_qonun = () => {
  const tabs = [
    {
      title: 'I BOB. Umumiy qoidalar', 
      content: (
        <>
          <span className="text-sky-600 text-3xl font-bold font-['Montserrat']">I BOB. Umumiy qoidalar</span>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>1-modda. Ushbu Qonunning maqsadi</h1>
            <p>Ushbu Qonunning maqsadi ta’lim sohasidagi munosabatlarni tartibga solishdan iborat.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>2-modda. Ta’lim to‘g‘risidagi qonunchilik</h1>
            <p>Ta’lim to‘g‘risidagi qonunchilik ushbu Qonun va boshqa qonunchilik hujjatlaridan iboratdir.

Agar O‘zbekiston Respublikasining xalqaro shartnomasida O‘zbekiston Respublikasining ta’lim to‘g‘risidagi qonunchiligida nazarda tutilganidan boshqacha qoidalar belgilangan bo‘lsa, xalqaro shartnoma qoidalari qo‘llaniladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>3-modda. Asosiy tushunchalar</h1>
            <p>Ushbu Qonunda quyidagi asosiy tushunchalar qo‘llaniladi:

davlat akkreditatsiyasi — davlat ta’lim muassasalari va tashkilotlari, shuningdek nodavlat ta’lim tashkilotlari (bundan buyon matnda ta’lim tashkilotlari deb yuritiladi) faoliyatining davlat ta’lim standartlari va davlat ta’lim talablariga hamda o‘quv dasturlariga muvofiqligining davlat tomonidan e’tirof etilishi hamda ularning bitiruvchilariga ma’lumot to‘g‘risidagi hujjatlarni topshirish huquqining taqdim etilishidan iborat jarayon;

davlat ta’lim muassasasi — davlat hokimiyati va boshqaruvi organlari tomonidan davlat mulki bo‘lgan mol-mulk negizida tashkil etilgan, davlat ta’lim standartlariga va davlat ta’lim talablariga muvofiq ta’lim beradigan muassasa;

davlat ta’lim standartlari — davlat tomonidan ta’limning mazmuni va sifatiga nisbatan belgilanadigan talablar majmui;

davlat ta’lim talablari — ta’limning tuzilmasiga, mazmuniga va uni amalga oshirish shart-sharoitlariga, shuningdek ta’lim oluvchilarning jismoniy, shaxsiy, intellektual, ilmiy hamda kasbiy sifatlariga qo‘yiladigan majburiy talablar;

malaka — shaxsning kasbiy faoliyatning muayyan turini bajarishga tayyorgarligini ifodalaydigan, ma’lumot to‘g‘risidagi tegishli hujjat bilan tasdiqlanadigan bilim, qobiliyat, mahorat va ko‘nikmalar darajasi;

mutaxassislik — malaka berish bilan yakunlanadigan muayyan kasbiy tayyorgarlik turining nomi;

nodavlat ta’lim tashkiloti — davlat ta’lim standartlari, davlat ta’lim talablari va o‘quv dasturlariga muvofiq ta’lim xizmatlari ko‘rsatish faoliyatini amalga oshirish huquqini beradigan litsenziya asosida yoki xabardor qilish tartibida ta’lim xizmatlari ko‘rsatuvchi yuridik shaxs;

tarbiya — aniq maqsadli hamda ijtimoiy-tarixiy tajriba asosida yosh avlodni har tomonlama kamol toptirishga, ularning ongini, ma’naviy-axloqiy qadriyatlar va dunyoqarashini shakllantirishga qaratilgan tizimli jarayon;

ta’lim — ta’lim oluvchilarga chuqur nazariy bilim, malakalar va amaliy ko‘nikmalar berishga, shuningdek ularning umumta’lim va kasbiy bilim, malaka hamda ko‘nikmalarini shakllantirishga, qobiliyatini rivojlantirishga qaratilgan tizimli jarayon;

ta’lim kampusi — yagona hududda birlashtirilgan o‘quv binolarini, ilmiy-tadqiqot institutlarini (markazlarini), ishlab chiqarish majmualari va texnoparklarni, ta’lim-tarbiya jarayoni ishtirokchilarining vaqtincha yashash joylarini, laboratoriyalarni, axborot-resurs markazlarini (kutubxonalarni), sport inshootlarini, umumiy ovqatlanish obyektlarini o‘z ichiga olgan binolar hamda inshootlar majmuidan iborat bo‘lgan, o‘quv jarayoni, ma’naviy-axloqiy tarbiyaning yuqori samaradorligini ta’minlaydigan ta’lim-tarbiya muhiti;

ta’lim-tarbiya jarayoni ishtirokchilari — ta’lim oluvchilar, voyaga yetmagan ta’lim oluvchilarning ota-onalari yoki boshqa qonuniy vakillari, pedagog xodimlar va ularning vakillari;

ta’lim tashkilotlari attestatsiyasi — ta’lim tashkilotlarining faoliyatini baholash, davlat ta’lim standartlari, davlat ta’lim talablari hamda o‘quv dasturlariga muvofiq kadrlar tayyorlash mazmuni, darajasi va sifatini aniqlash bo‘yicha davlat nazoratining asosiy shakli.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>4-modda. Ta’lim sohasidagi asosiy prinsiplar</h1>
            <p>Ta’lim sohasidagi asosiy prinsiplar quyidagilardan iborat:

ta’lim ustuvorligining tan olinishi;

ta’lim olish shaklini tanlash erkinligi;

ta’lim sohasida kamsitishlarga yo‘l qo‘yilmasligi;

ta’lim olishga doir teng imkoniyatlarning ta’minlanishi;

ta’lim va tarbiyaga milliy hamda umuminsoniy qadriyatlarning singdirilganligi;

ta’lim va tarbiyaning insonparvarlik, demokratik xususiyati;

ta’limning uzluksizligi va izchilligi;

o‘n bir yillik ta’limning hamda olti yoshdan yetti yoshgacha bo‘lgan bolalarni bir yil davomida umumiy o‘rta ta’limga tayyorlashning majburiyligi;

davlat ta’lim standartlari va davlat ta’lim talablari doirasida ta’lim olishning hamma uchun ochiqligi;

o‘quv dasturlarini tanlashga doir yondashuvning yagonaligi va tabaqalashtirilganligi;

insonning butun hayoti davomida ta’lim olishi;

jamiyatda pedagoglarni ijtimoiy himoya qilishning kafolatlanganligi;

ta’lim tizimining dunyoviy xususiyatga egaligi;

bilimlilik, qobiliyatlilik va iste’dodning rag‘batlantirilishi;

ta’lim tizimida davlat va jamoat boshqaruvining uyg‘unligi;

ta’lim faoliyati sohasidagi ochiqlik va shaffoflik.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>5-modda. Ta’lim olish huquqi</h1>
            <p>Jinsi, irqi, millati, tili, dini, ijtimoiy kelib chiqishi, e’tiqodi, shaxsiy va ijtimoiy mavqeyidan qat’i nazar, har kimga ta’lim olish uchun teng huquqlar kafolatlanadi.

Ta’lim olish huquqi:

ta’lim tashkilotlarini rivojlantirish;

ta’lim tashkilotlarida innovatsion faoliyatni qo‘llab-quvvatlash va o‘quv dasturlarini innovatsion texnologiyalarni qo‘llagan holda amalga oshirish;

ishlab chiqarishdan ajralgan (kunduzgi) va ajralmagan holda (sirtqi, kechki, masofaviy) ta’lim olishni tashkil etish;

kadrlarni tayyorlash, qayta tayyorlash va ularning malakasini oshirish;

umumiy o‘rta, o‘rta maxsus ta’limni va boshlang‘ich professional ta’limni bepul olish;

oilada yoki mustaqil o‘qish orqali ta’lim olgan fuqarolarga, shuningdek umumiy o‘rta ta’lim olmagan shaxslarga akkreditatsiyadan o‘tgan davlat ta’lim muassasalarida eksternat tartibida attestatsiyadan o‘tish huquqini berish orqali ta’minlanadi.

Chet ellik fuqarolar O‘zbekiston Respublikasining xalqaro shartnomalariga va qonunchiligiga muvofiq O‘zbekiston Respublikasida ta’lim olishga haqlidir.

O‘zbekiston Respublikasida doimiy yashayotgan fuqaroligi bo‘lmagan shaxslar ta’lim olish uchun O‘zbekiston Respublikasi fuqarolari bilan teng huquqlarga ega.</p>
          </div>
        </>
      )
    },
    {
      title: 'II BOB. Ta’lim tizimi, turlari va shakllari', 
      content: (
        <>
          <span className="text-sky-600 text-3xl font-bold font-['Montserrat']">II BOB. Ta'lim tizimi</span>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>6-modda. Ta’lim tizimi</h1>
            <p>Ta’lim tizimi:

davlat ta’lim standartlarini, davlat ta’lim talablarini, o‘quv rejalari va o‘quv dasturlarini;

davlat ta’lim standartlarini, davlat ta’lim talablari va o‘quv dasturlarini amalga oshiruvchi ta’lim tashkilotlarini;

ta’lim sifatini baholashni amalga oshiruvchi tashkilotlarni;

ta’lim tizimining faoliyat ko‘rsatishi va rivojlanishini ta’minlash uchun zarur bo‘lgan tadqiqot ishlarini bajaruvchi ilmiy-pedagogik muassasalarni;

ta’lim sohasidagi davlat boshqaruvi organlarini, shuningdek ularning tasarrufidagi tashkilotlarni o‘z ichiga oladi.

Ta’lim tizimi yagona va uzluksizdir.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>7-modda. Ta’lim turlari</h1>
            <p>Ta’lim turlari quyidagilardan iborat:

maktabgacha ta’lim va tarbiya;

umumiy o‘rta va o‘rta maxsus ta’lim;

professional ta’lim;

oliy ta’lim;

oliy ta’limdan keyingi ta’lim;

kadrlarni qayta tayyorlash va ularning malakasini oshirish;

maktabdan tashqari ta’lim.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>8-modda. Maktabgacha ta’lim va tarbiya</h1>
            <p>Maktabgacha ta’lim va tarbiya bolalarni o‘qitish va tarbiyalashga, ularni intellektual, ma’naviy-axloqiy, etik, estetik va jismoniy jihatdan rivojlantirishga, shuningdek bolalarni umumiy o‘rta ta’limga tayyorlashga qaratilgan ta’lim turidir.

Maktabgacha ta’lim va tarbiya olti yoshdan yetti yoshgacha bo‘lgan bolalarni boshlang‘ich ta’limga bir yillik majburiy tayyorlashni ham nazarda tutadi.

Maktabgacha ta’lim va tarbiyani tashkil etish tartibi ushbu Qonun, shuningdek “Maktabgacha ta’lim va tarbiya to‘g‘risida”gi O‘zbekiston Respublikasi Qonuni bilan belgilanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>9-modda. Umumiy o'rta va o'rta maxsus ta'lim</h1>
            <p>Umumiy o'rta va o'rta maxsus ta'lim umumta'lim o'quv dasturlarini, zarur bilim, malaka hamda ko'nikmalarni o'zlashtirishga qaratilgan.

Umumiy o'rta ta'lim (I — XI sinflar) bosqichlari quyidagilardan iborat:

boshlang'ich ta'lim (I — IV sinflar);

tayanch o'rta ta'lim (V — IX sinflar);

o'rta ta'lim (X — XI sinflar).

Umumiy o'rta ta'lim tashkilotining birinchi sinfiga bolalar ular yetti yoshga to'ladigan yilda qabul qilinadi.

Boshlang'ich ta'lim ta'lim oluvchilarda umumiy o'rta ta'limni davom ettirish uchun zarur bo'lgan savodxonlik, bilim, malaka va ko'nikmalar asoslarini shakllantirishga qaratilgan.

Tayanch o'rta ta'lim o'quv dasturiga muvofiq ta'lim oluvchilarga bilim, malaka va ko'nikmalarning zaruriy hajmini beradi, ularda mustaqil fikrlash va tahlil qilish qobiliyatini rivojlantiradi.

Tayanch o'rta ta'lim doirasida (VII sinfdan so'ng) ta'lim oluvchilarda kasblar bo'yicha birlamchi bilim va ko'nikmalarni shakllantirish uchun ularni professional tashxislash va kasb-hunarga yo'naltirish bo'yicha choralar amalga oshiriladi.

O'rta ta'lim o'quv dasturiga muvofiq ta'lim oluvchilar tomonidan zarur bilim, malaka va ko'nikmalarni o'zlashtirilishini, shuningdek ta'limning keyingi turi tanlanishini hamda yuqori malaka talab qilinmaydigan kasblar egallanishini ta'minlaydi.

Professional tashxislash va kasb-hunarga yo'naltirish, shuningdek ta'lim oluvchilarni yuqori malaka talab qilinmaydigan kasblarga tayyorlash tartibi qonunchilikda belgilanadi.

Umumiy o'rta ta'lim umumiy o'rta ta'lim tashkilotlarida uzluksiz tarzda, majburiy bo'lgan o'n bir yil davomida amalga oshiriladi.

O'rta maxsus ta'lim akademik litseylarda to'qqiz yillik tayanch o'rta ta'lim asosida ikki yil mobaynida amalga oshiriladi va ta'lim oluvchilarning intellektual qobiliyatlarining jadal rivojlanishini, shuningdek chuqur, tabaqalashtirilgan, kasb-xunarga va shaxsga yo'naltirilgan ta'lim olishini ta'minlaydi.

Nodavlat ta'lim tashkilotlarida umumiy o'rta va o'rta maxsus ta'lim to'lov-shartnoma asosida amalga oshirilishi mumkin.

Iqtidorli va iste'dodli bolalarning qobiliyatini rivojlantirish uchun Prezident, ijod va boshqa ixtisoslashtirilgan maktablar, shuningdek maktab-internatlar tashkil etilishi mumkin.

Jismoniy, aqliy, sensor (sezgi) yoki ruhiy nuqsonlari bo'lgan bolalar, shuningdek uzoq vaqt davolanishga muhtoj bo'lgan bolalar davlat ixtisoslashtirilgan ta'lim muassasalarida, umumiy o'rta va o'rta maxsus ta'lim tashkilotlarida inklyuziv shaklda yoki uy sharoitlarida yakka tartibda ta'lim oladi.

Umumiy o'rta ta'lim tashkilotlarining sinflarida (guruhlarida) ta'lim oluvchilar soni o'ttiz besh nafardan oshmasligi kerak.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>10-modda. Professional ta'lim</h1>
            <p>Professional ta'lim egallanadigan kasb va mutaxassislik bo'yicha quyidagi darajalarni o'z ichiga oladi:

boshlang'ich professional ta'lim;

o'rta professional ta'lim;

o'rta maxsus professional ta'lim.

Boshlang'ich professional ta'lim kasb-hunar maktablarida IX sinf bitiruvchilari negizida bepul asosda kunduzgi ta'lim shakli bo'yicha umumta'lim fanlarining va mutaxassislik fanlarining ikki yillik integratsiyalashgan dasturlari asosida amalga oshiriladi.

O'rta professional ta'lim kollejlarda davlat buyurtmasi yoki to'lov-shartnoma asosida kasblar hamda mutaxassisliklarning murakkabligidan kelib chiqqan holda, davomiyligi ikki yilgacha bo'lgan kunduzgi, kechki va sirtqi ta'lim shakllari bo'yicha umumiy o'rta, o'rta maxsus ta'lim hamda boshlang'ich professional ta'lim negizida amalga oshiriladi.

O'rta maxsus professional ta'lim texnikumlarda umumiy o'rta, o'rta maxsus, boshlang'ich professional va o'rta professional ta'lim negizida davlat buyurtmasi yoki to'lov-shartnoma asosida kasblar hamda mutaxassisliklarning murakkabligidan kelib chiqqan holda, davomiyligi kamida ikki yil bo'lgan kunduzgi, kechki va sirtqi ta'lim shakllari bo'yicha amalga oshiriladi.

Ushbu Qonun kuchga kirguniga qadar o'rta maxsus, kasb-hunar ta'limi (to'qqiz yillik umumiy o'rta va uch yillik o'rta maxsus, kasb-hunar ta'limi) olgan fuqarolar ham o'rta professional va o'rta maxsus professional ta'lim olish huquqiga ega.

Kasb-hunar maktablari, kollejlar va texnikumlar ta'lim oluvchilarning o'zi tanlagan kasbga va mutaxassislikka ega bo'lishini ta'minlaydi.

Fuqarolar shartnoma asosida ikkinchi va undan keyingi professional ta'limni olish huquqiga ega.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>11-modda. Oliy ta'lim</h1>
            <p>Oliy ta'lim bakalavriat ta'lim yo'nalishlari va magistratura mutaxassisliklari bo'yicha yuqori malakali kadrlar tayyorlanishini ta'minlaydi.

Oliy ma'lumotli kadrlarni tayyorlash oliy ta'lim tashkilotlarida (universitetlar, akademiyalar, institutlar, oliy maktablar) amalga oshiriladi. Umumiy o'rta (o'n bir yillik ta'lim), o'rta maxsus (to'qqiz yillik tayanch o'rta va ikki yillik o'rta maxsus ta'lim), boshlang'ich professional ta'lim (to'qqiz yillik tayanch o'rta va ikki yillik boshlang'ich professional ta'lim) olgan shaxslar, shuningdek ushbu Qonun kuchga kirguniga qadar o'rta maxsus, kasb-hunar ta'limi (to'qqiz yillik umumiy o'rta va uch yillik o'rta maxsus, kasb-hunar ta'limi) olgan shaxslar oliy ma'lumot olish huquqiga ega.

Oliy ta'lim ikki bosqichga — bakalavriat va magistratura bosqichiga ega.

Bakalavriat oliy ta'lim yo'nalishlaridan biri bo'yicha chuqurlashtirilgan bilim, malaka va ko'nikmalar beradigan, o'qish davomiyligi kamida uch yil bo'lgan tayanch oliy ta'limdir.

Magistratura tegishli bakalavriat negizidagi aniq mutaxassislik bo'yicha o'qish davomiyligi kamida bir yil bo'lgan oliy ta'limdir.

Magistratura mutaxassisliklarining va ularga muvofiq bo'lgan bakalavriat ta'lim yo'nalishlarining ro'yxati ta'lim sohasidagi vakolatli davlat boshqaruvi organi tomonidan belgilanadi.

Fuqarolar shartnoma asosida ikkinchi va undan keyingi oliy ma'lumotni olish huquqiga ega.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>12-modda. Oliy ta'limdan keyingi ta'lim</h1>
            <p>Oliy ta'limdan keyingi ta'limni oliy ta'lim va ilmiy tashkilotlarda olish mumkin.

Oliy ta'limdan keyingi ta'lim doktorlik dissertatsiyasini tayyorlash va himoya qilish maqsadida mutaxassislikni chuqur o'rganishni va ilmiy izlanishlar olib borishni nazarda tutadigan tayanch doktorantura, doktorantura va mustaqil izlanuvchanlik asosida ilmiy darajaga ega ilmiy va ilmiy-pedagogik kadrlar tayyorlashni ta'minlaydi.

Tayanch doktorantura falsafa doktori (Doctor of Philosophy (PhD) ilmiy darajasiga da'vogar izlanuvchilar uchun ishlab chiqarishdan ajralgan holda tashkil etiladigan oliy malakali ilmiy va ilmiy-pedagog kadrlar ixtisosligi bo'yicha oliy ta'limdan keyingi ta'lim shakli hisoblanadi.

Doktorantura fan doktori (Doctor of Science (DSc) ilmiy darajasiga da'vogar izlanuvchilar uchun ishlab chiqarishdan ajralgan holda tashkil etiladigan oliy malakali ilmiy va ilmiy-pedagog kadrlar ixtisosligi bo'yicha oliy ta'limdan keyingi ta'lim shakli hisoblanadi.

Mustaqil izlanuvchilik falsafa doktori (Doctor of Philosophy (PhD) yoki fan doktori (Doctor of Science (DSc) ilmiy darajalariga da'vogar izlanuvchilar uchun ishlab chiqarishdan ajralmagan holda tashkil etiladigan oliy malakali ilmiy va ilmiy-pedagog kadrlar ixtisosligi bo'yicha oliy ta'limdan keyingi ta'lim shakli hisoblanadi.

Ilmiy va ilmiy-pedagogik kadrlar tayyorlash, ilmiy darajalar va ilmiy unvonlar berish tartibi, shuningdek harbiy, tibbiyot va boshqa ta'lim tashkilotlarida oliy ta'limdan keyingi ta'lim olish xususiyatlari qonunchilikda belgilanadi.

Oliy ta'limdan keyingi ta'limning davom etish muddati qonunchilikda belgilanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>13-modda. Kadrlarni qayta tayyorlash va ularning malakasini oshirish</h1>
            <p>Kadrlarni qayta tayyorlash tayanch mutaxassisliklar va kasblarga muvofiq bo'lgan yo'nalishlar bo'yicha faoliyatni amalga oshirish uchun qo'shimcha kasbiy bilim, malaka va ko'nikmalarning zarur hajmi egallanishini ta'minlaydi.

Kadrlar malakasini oshirish kasbiy bilim, malaka va ko'nikmalarning chuqurlashtirilishi hamda yangilab borilishini ta'minlaydi, kadrlarning toifasi, darajasi, razryadi va lavozimi oshishiga xizmat qiladi.

Kadrlarni qayta tayyorlash va ularning malakasini oshirish shakllari va muddatlari tegishli davlat ta'lim talablari bilan belgilanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>14-modda. Maktabdan tashqari ta'lim</h1>
            <p>Bolalarning ehtiyojlarini qanoatlantirish, bo'sh vaqti va dam olishini tashkil etish uchun davlat organlari, nodavlat notijorat tashkilotlari, shuningdek tijorat tashkilotlari madaniy-estetik, ilmiy, texnikaviy, sport yo'nalishidagi maktabdan tashqari ta'lim tashkilotlarini tashkil etishi mumkin.

Maktabdan tashqari ta'lim bolalarga uzluksiz ta'lim berishning tarkibiy qismi sifatida ularning iste'dodi va qobiliyatini rivojlantirishga, ma'naviy ehtiyojlarini qanoatlantirishga qaratilgan.

Maktabdan tashqari ta'lim tashkilotlari jumlasiga bolalar, o'smirlar ijodiyoti saroylari, uylari, klublari va markazlari, "Barkamol avlod" bolalar maktablari, bolalar-o'smirlar sport maktablari, bolalar musiqa va san'at maktablari, studiyalar, axborot-kutubxona hamda sog'lomlashtirish muassasalari kiradi.

Maktabdan tashqari ta'lim berish tartibi ta'lim sohasidagi vakolatli davlat boshqaruvi organi tomonidan belgilanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>15-modda. Ta'lim olish shakllari</h1>
            <p>Ta'lim olish shakllari quyidagilardan iborat:

ishlab chiqarishdan ajralgan holda ta'lim olish (kunduzgi);

ishlab chiqarishdan ajralmagan holda ta'lim olish (sirtqi, kechki, masofaviy);

dual ta'lim;

oilada ta'lim olish va mustaqil ta'lim olish;

katta yoshdagilarni o'qitish va ularga ta'lim berish;

inklyuziv ta'lim;

eksternat tartibidagi ta'lim;

mudofaa, xavfsizlik va huquqni muhofaza qilish faoliyati sohasida kadrlar tayyorlash.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>16-modda. Masofaviy ta'lim</h1>
            <p>Masofaviy ta'lim o'quv rejalari va o'quv dasturlariga muvofiq ta'lim oluvchilar tomonidan zarur bilim, malaka va ko'nikmalarni axborot-kommunikatsiya texnologiyalaridan hamda Internet jahon axborot tarmog'idan foydalangan holda masofadan turib olishga qaratilgan.

Masofaviy ta'limni tashkil etish tartibi O'zbekiston Respublikasi Vazirlar Mahkamasi tomonidan belgilanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>17-modda. Dual ta'lim</h1>
            <p>Dual ta'lim ta'lim oluvchilar tomonidan zarur bilim, malaka va ko'nikmalarni olishga qaratilgan bo'lib, ularning nazariy qismi ta'lim tashkiloti negizida, amaliy qismi esa ta'lim oluvchining ish joyida amalga oshiriladi.

Dual ta'limni tashkil etish tartibi O'zbekiston Respublikasi Vazirlar Mahkamasi tomonidan belgilanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>18-modda. Oilada ta'lim olish va mustaqil ta'lim olish</h1>
            <p>Davlat oilada ta'lim olishga va mustaqil ta'lim olishga ko'maklashadi. Bolalarning oilada ta'lim olishi va mustaqil ta'lim olish uslubiy va maslahat yordami ko'rsatilgan holda tegishli o'quv dasturlari bo'yicha amalga oshiriladi.

Oilada ta'lim olish va mustaqil ta'lim olish tartibi, shuningdek ta'lim oluvchilarning toifalari ta'lim sohasidagi vakolatli davlat boshqaruvi organlari tomonidan belgilanadi.

Oilada ta'lim olish bolalar, oila, davlat va jamiyat manfaatlarini hisobga olgan holda davlat ta'lim muassasasi hamda ta'lim oluvchilarning ota-onasi yoki boshqa qonuniy vakillari o'rtasidagi shartnoma asosida amalga oshiriladi.

Mustaqil ta'lim olish yakka tartibda amalga oshiriladi hamda ta'lim oluvchilarni kasbiy, intellektual, ma'naviy va madaniy rivojlantirishga xizmat qiladi.

Oilada ta'lim olgan va mustaqil ta'lim olgan shaxslarga davlat tomonidan tasdiqlangan namunadagi ta'lim to'g'risidagi hujjatni berish davlat ta'lim muassasalarining tasdiqlangan o'quv dasturiga muvofiq eksternat tartibida amalga oshiriladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>19-modda. Katta yoshdagilarni o'qitish va ularga ta'lim berish</h1>
            <p>Katta yoshdagilarni o'qitish va ularga ta'lim berish butun umr davomida o'qitishning markaziy tarkibiy qismi bo'lib, ta'lim berish hamda o'qitishning jamiyat hayotida va mehnat faoliyatida katta yoshdagilarning ishtirok etishini ta'minlashga qaratilgan barcha shakllarini o'z ichiga oladi, shuningdek rasmiy, norasmiy va informal o'qitish jarayonlarining butun majmuini qamrab oladi.

Rasmiy ta'lim davlat ta'lim muassasalari hamda davlat tomonidan tan olingan akkreditatsiyadan o'tgan nodavlat ta'lim tashkilotlari ishtirokidagi institutsionallashtirilgan (muayyan qoidalar va normalarni mujassamlashtiruvchi), aniq maqsadga yo'naltirilgan va rejalashtirilgan ta'limdir.

Norasmiy ta'lim ta'lim xizmatlari taqdim etilishini ta'minlovchi shaxs yoki tashkilot tomonidan institutsionallashtirilgan (muayyan qoidalar va normalarni mujassamlashtiruvchi), aniq maqsadga yo'naltirilgan va rejalashtirilgan bo'lib, shaxsni butun hayoti davomida o'qitishdagi rasmiy ta'limga qo'shimcha va (yoki) uning muqobilidir.

Informal ta'lim aniq maqsadga yo'naltirilgan, ammo institutsionallashtirilmagan (muayyan qoidalar va normalarni mujassamlashtirmagan), rasmiy yoki norasmiy ta'limdan ko'ra kamroq tashkillashtirilgan va tarkiblashtirilgandir hamda oiladagi, ish joyidagi, yashash joyidagi va kundalik hayotdagi o'quv faoliyatini o'z ichiga olishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>20-modda. Inklyuziv ta'lim</h1>
            <p>Inklyuziv ta'lim alohida ta'lim ehtiyojlari va individual imkoniyatlarning xilma-xilligini hisobga olgan holda barcha ta'lim oluvchilar uchun ta'lim tashkilotlarida ta'lim olishga bo'lgan teng imkoniyatlarni ta'minlashga qaratilgan.

Jismoniy, aqliy, sensor (sezgi) yoki ruhiy nuqsonlari bo'lgan bolalar (shaxslar) uchun ta'lim tashkilotlarida inklyuziv ta'lim tashkil etiladi.

Inklyuziv ta'limni tashkil etish tartibi O'zbekiston Respublikasi Vazirlar Mahkamasi tomonidan belgilanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>21-modda. Eksternat tartibidagi ta'lim</h1>
            <p>Eksternat tartibidagi ta'lim olish o'quv dasturlarini mustaqil ravishda o'zlashtirishni o'z ichiga olib, uning yakunlari bo'yicha ta'lim oluvchilardan davlat ta'lim muassasalarida yakuniy va davlat attestatsiyalaridan o'tishni talab etadi.

Eksternat tartibidagi ta'lim olishni tashkil etish tartibi O'zbekiston Respublikasi Vazirlar Mahkamasi tomonidan belgilanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>22-modda. Mudofaa, xavfsizlik va huquqni muhofaza qilish faoliyati sohasida kadrlarni tayyorlash</h1>
            <p>Mudofaa, xavfsizlik va huquqni muhofaza qilish faoliyati sohasida kadrlarni tayyorlash ularning o'ziga xos xususiyatlaridan kelib chiqqan holda qonunchilikka muvofiq amalga oshiriladi.</p>
          </div>
        </>
      )
    },
    {
      title: 'III BOB. Ta’lim tizimini boshqarish', 
      content: (
        <>
          <span className="text-sky-600 text-3xl font-bold font-['Montserrat']">3-bob. Ta'lim tizimini boshqarish</span>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>23-modda. O'zbekiston Respublikasi Vazirlar Mahkamasining ta'lim sohasidagi vakolatlari</h1>
            <p>O'zbekiston Respublikasi Vazirlar Mahkamasi:

ta'lim sohasidagi yagona davlat siyosatini amalga oshiradi;

ta'lim sohasidagi davlat dasturlarini tasdiqlaydi va ularning amalga oshirilishini ta'minlaydi;

ta'lim sohasidagi vakolatli davlat boshqaruvi organlariga rahbarlik qiladi;

ta'lim tashkilotlarini attestatsiyadan va davlat akkreditatsiyasidan, pedagog kadrlarni va ilmiy xodimlarni attestatsiyadan o'tkazish, nodavlat ta'lim tashkilotlariga ta'lim xizmatlari ko'rsatish faoliyatini amalga oshirish huquqini beradigan litsenziyalar (bundan buyon matnda litsenziya deb yuritiladi) berish vakolatli organni ushbu sohada faoliyat boshlash to'g'risida xabardor qilish, ta'lim to'g'risidagi hujjatlarga apostil qo'yish tartibini belgilaydi;

pedagogik kadrlarni ta'lim tashkilotlariga ishga qabul qilish va ular faoliyatini baholash tartibini belgilaydi;

xorijiy davlatlarning ta'lim muassasalariga O'zbekiston Respublikasi hududida ta'lim faoliyati bilan shug'ullanish huquqiga doir ruxsatnomalar beradi;

xorijiy davlatlarda olingan ta'lim to'g'risidagi hujjatlarni tan olish tartibini belgilaydi;

davlat namunasidagi ta'lim to'g'risidagi hujjatlarni tasdiqlaydi va davlat tomonidan tasdiqlangan namunadagi ta'lim to'g'risidagi hujjatlar berish tartibini belgilaydi;

eksternat tartibida o'qitishga yo'l qo'yilmaydigan ta'lim yo'nalishlari, mutaxassisliklar va kasblar ro'yxatini tasdiqlaydi;

faqat davlat ta'lim muassasalarida o'qitiladigan ta'lim yo'nalishlari, mutaxassisliklar va kasblar ro'yxatini tasdiqlaydi;

davlat ta'lim muassasalari va tashkilotlariga qabul qilish tartibini belgilaydi;

davlat oliy ta'lim muassasalari rektorlarini, shuningdek davlat ishtirokida tashkil etiladigan oliy ta'lim tashkilotlari (davlat ulushi bo'lgan nodavlat oliy ta'lim tashkilotlari, qo'shma ta'lim muassasalari, davlat-xususiy sheriklik asosida tashkil etiladigan ta'lim muassasalari va boshqalar) rektorlarini (rahbarlarini) lavozimga tayinlaydi hamda egallab turgan lavozimidan ozod etadi;

ta'lim oluvchilarni akkreditatsiya qilingan bir ta'lim tashkilotidan boshqasiga ko'chirish, shuningdek ularni o'qishdan chetlashtirish va qayta tiklash tartibini belgilaydi;

ta'lim tashkilotlari reytingini aniqlash tartibini belgilaydi;

kadrlarni qayta tayyorlash va ularning malakasini oshirish tartibini belgilaydi;

mehnat bozori talablarini prognoz va tahlil qilish asosida ta'lim tashkilotlarida kadrlarni tayyorlash bo'yicha davlat buyurtmalarini shakllantiradi;

ta'lim tashkilotlariga nisbatan moddiy-texnik, infratuzilmaviy va parametrik talablarni belgilaydi;

darsliklar va o'quv qo'llanmalarini tayyorlash hamda nashr etish tartibini, shuningdek ularni yetkazib berishga va ulardan ta'lim tashkilotlarida foydalanishga qo'yiladigan talablarni belgilaydi.

O'zbekiston Respublikasi Vazirlar Mahkamasi qonunchilikka muvofiq boshqa vakolatlarni ham amalga oshirishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>24-modda. O'zbekiston Respublikasi Vazirlar Mahkamasi huzuridagi Ta'lim sifatini nazorat qilish davlat inspeksiyasining ta'lim sohasidagi vakolatlari</h1>
            <p>O'zbekiston Respublikasi Vazirlar Mahkamasi huzuridagi Ta'lim sifatini nazorat qilish davlat inspeksiyasi (bundan buyon matnda Ta'lim inspeksiyasi deb yuritiladi) ta'lim tizimida o'quv-tarbiya jarayoni, professor-o'qituvchilar tarkibi, kadrlarni tayyorlash, qayta tayyorlash va ularning malakasini oshirish sifati ustidan nazorat qilish sohasida davlat siyosatini amalga oshiradigan, ta'lim sohasidagi maxsus vakolatli davlat boshqaruvi organidir.

Ta'lim inspeksiyasi:

ta'lim tashkilotlarini (bundan maktabdan tashqari ta'lim xizmatlarini ko'rsatuvchi nodavlat ta'lim tashkilotlari mustasno) attestatsiyadan va davlat akkreditatsiyasidan, shuningdek ta'lim tashkilotlarining pedagog xodimlarini attestatsiyadan o'tkazadi;

ta'lim tashkilotlarida ta'lim-tarbiya jarayonining sifati monitoringini amalga oshiradi;

maktabgacha, umumiy o'rta, o'rta maxsus, professional va maktabdan tashqari ta'lim tashkilotlarining pedagog xodimlariga lavozimlar va malaka toifalarini berish jarayonini nazorat qiladi hamda unda ishtirok etadi;

nodavlat ta'lim tashkilotlariga litsenziyalar beradi faoliyatini xabardor qilish tartibida amalga oshiradigan shaxslardan xabarnomalar qabul qiladi va ularning reyestrini yuritadi;

ta'lim tashkilotlarining reytingini aniqlaydi;

aniqlangan ta'lim to'g'risidagi qonunchilik buzilishlari yuzasidan tegishli davlat boshqaruvi organlariga va ta'lim tashkilotlariga taqdimnomalar kiritadi.

Ta'lim inspeksiyasi qonunchilikka muvofiq boshqa vakolatlarni ham amalga oshirishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>25-modda. O'zbekiston Respublikasi Vazirlar Mahkamasi huzuridagi Prezident, ijod va ixtisoslashtirilgan maktablarni rivojlantirish agentligining ta'lim sohasidagi vakolatlari</h1>
            <p>O'zbekiston Respublikasi Vazirlar Mahkamasi huzuridagi Prezident, ijod va ixtisoslashtirilgan maktablarni rivojlantirish agentligi:

Prezident, ijod va ixtisoslashtirilgan maktablarda yoshlarni aniqlash, tanlash, o'qitish va tarbiyalash sohasida davlat siyosatini ishlab chiqadi va uni amalga oshiradi;

Prezident, ijod va ixtisoslashtirilgan maktablar uchun davlat ta'lim standartlarini tasdiqlaydi;

davlat ta'lim standartlariga muvofiq Prezident, ijod va ixtisoslashtirilgan maktablar faoliyatini yagona tarzda muvofiqlashtirishni hamda unga uslubiy rahbarlik qilishni amalga oshiradi;

Prezident, ijod va ixtisoslashtirilgan maktablarning moddiy-texnika bazasini mustahkamlaydi, mazkur maktablarda bino va inshootlarni ekspluatatsiya qilish ishlarini monitoring qiladi va muvofiqlashtiradi.

O'zbekiston Respublikasi Vazirlar Mahkamasi huzuridagi Prezident, ijod va ixtisoslashtirilgan maktablarni rivojlantirish agentligi qonunchilikka muvofiq boshqa vakolatlarni ham amalga oshirishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>26-modda. Ta'lim sohasidagi vakolatli davlat boshqaruvi organlari</h1>
            <p>O'zbekiston Respublikasi Maktabgacha ta'lim vazirligi, Xalq ta'limi vazirligi, Oliy va o'rta maxsus ta'lim vazirligi ta'lim sohasidagi vakolatli davlat boshqaruvi organlaridir.

Ta'lim sohasidagi vakolatli davlat boshqaruvi organlari o'z vakolatlari doirasida:

ta'lim sohasidagi yagona davlat siyosatini amalga oshiradi;

ta'lim sohasidagi tarmoq davlat dasturlarini ishlab chiqadi, tasdiqlaydi va amalga oshiradi;

ta'lim tashkilotlari faoliyatini muvofiqlashtiradi va ularga uslubiy rahbarlik qilishni amalga oshiradi;

davlat ta'lim standartlari (shu jumladan maktabgacha ta'lim va tarbiya davlat standarti) va davlat ta'lim talablarida kadrlarning ma'lumoti darajasiga va kasbiy tayyorgarligi sifatiga qo'yilgan talablarning ta'lim tashkilotlari tomonidan bajarilishi ustidan nazoratni amalga oshiradi;

davlat ta'lim standartlari (shu jumladan maktabgacha ta'lim va tarbiya davlat standartini) va davlat ta'lim talablari ishlab chiqilishini ta'minlaydi va ularni tasdiqlaydi;

ta'lim oluvchilarning bilim, malaka va ko'nikmalarini baholash tartibini belgilaydi;

professional ta'limning kasblar va mutaxassisliklar, oliy ta'limning bakalavriat ta'lim yo'nalishlari va magistratura mutaxassisliklari, shuningdek bilim sohalari va ta'lim sohalari ro'yxatini belgilaydi;

ta'lim-tarbiya jarayoniga o'qitishning ilg'or shakllari, yangi pedagogik texnologiyalar, o'qitishning texnik va axborot vositalari joriy etilishini ta'minlaydi;

ta'lim tashkilotlarida kadrlarning kasbiy tayyorgarligi sifatini oshirishga qaratilgan chora-tadbirlarni ishlab chiqadi, o'quv dasturlarini takomillashtiradi;

o'quv adabiyotlarini tayyorlash va nashr qilishni tashkil etadi;

o'zlashtirishni baholashga, o'quv jarayonini, ta'lim oluvchilarning yakuniy davlat attestatsiyasini tashkil etishga oid normativ-huquqiy hujjatlarni tasdiqlaydi, shuningdek eksternat tartibida ta'lim oluvchilarning toifalarini belgilaydi;

davlat oliy ta'lim muassasalarining rektorlarini tayinlash to'g'risida O'zbekiston Respublikasi Vazirlar Mahkamasiga takliflar kiritadi;

ta'lim tashkilotlarining rahbar va pedagog kadrlarini tayyorlashni, qayta tayyorlashni va ularning malakasini oshirishni tashkil etadi;

ta'lim tashkilotlarida moddiy-texnika resurslaridan foydalanishga doir talablarni ishlab chiqadi;

ta'lim sohasidagi normativ-huquqiy hujjatlarni ishlab chiqishda ishtirok etadi;

ta'lim sohasida xalqaro hamkorlikni amalga oshiradi.

Ta'lim sohasidagi vakolatli davlat boshqaruvi organlari qonunchilikka muvofiq boshqa vakolatlarni ham amalga oshirishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>27-modda. Mahalliy davlat hokimiyati organlarining ta'lim sohasidagi vakolatlari</h1>
            <p>Mahalliy davlat hokimiyati organlari:

ta'lim sohasidagi vakolati davlat boshqaruvi organlari bilan kelishilgan holda davlat ta'lim muassasalarini tashkil etadi, qayta tashkil etadi va tugatadi, bundan respublika tasarrufidagi ta'lim muassasalari mustasno;

o'z vakolatlari doirasida tegishli hududda davlat ta'lim muassasalari uchun moliyalashtirish hajmini belgilaydi;

fuqarolarning o'zini o'zi boshqarish organlari, nodavlat notijorat tashkilotlari va fuqarolik jamiyatining boshqa institutlari bilan ta'lim tashkilotlarini rivojlantirish masalalari yuzasidan hamkorlik qiladi;

davlat umumiy o'rta ta'lim muassasalariga biriktirilgan hududlarni (mikrouchastkalarni) belgilaydi;

ta'lim sohasida xalqaro hamkorlikni amalga oshirishda ta'lim tashkilotlariga ko'maklashadi;

ta'lim oluvchilar uchun sifatli ta'limni, tarbiyani ta'minlash, ularning iste'dodini shakllantirish va namoyon etish maqsadida joylarda ularga zarur sharoitlar yaratish bo'yicha dasturlarni ishlab chiqadi;

o'z vakolatlari doirasida ta'lim sohasidagi davlat-xususiy sheriklikni rivojlantiradi va nodavlat ta'lim tashkilotlari tarmog'ini kengaytirishga ko'maklashadi;

umumiy o'rta ta'lim tashkilotlari bitiruvchilari bandligini ta'minlashga ko'maklashadi.

Mahalliy davlat hokimiyati organlari qonunchilikka muvofiq boshqa vakolatlarni ham amalga oshirishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>28-modda. Ta'lim tashkilotini boshqarish</h1>
            <p>Ta'lim tashkilotini boshqarishni tegishincha quyidagilar amalga oshiradi:

pedagogik kengash;

kuzatuv (vasiylik) kengashi;

oliy ta'lim tashkilotining kengashi;

ta'lim tashkilotining rahbari.

Ta'lim tashkilotlarida jamoatchilik boshqaruvi organlari tashkil etilishi mumkin.

Ta'lim tashkilotlarini boshqarishda va kadrlar tayyorlashda kadrlar talabgorlari ishtirok etadi.</p>
          </div>
        </>
      )
    },
    {
      title: 'IV BOB. Ta’lim faoliyatini tashkil etish va uning nazoratini amalga oshirish', 
      content: (
        <>
          <span className="text-sky-600 text-3xl font-bold font-['Montserrat']">4-bob. Ta'lim faoliyatini tashkil etish va uning nazoratini amalga oshirish</span>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>29-modda. Ta’lim tashkilotlarining huquqiy maqomi</h1>
            <p>O‘zbekiston Respublikasining ta’lim tashkilotlari va ularning filiallari, shuningdek xorijiy davlatlar ta’lim tashkilotlarining filiallari yuridik shaxs maqomi bilan tashkil etiladi.

Oilaviy nodavlat maktabgacha ta’lim tashkiloti shaklidagi ta’lim xizmatlari yakka tartibdagi tadbirkorlar sifatida ro‘yxatga olingan jismoniy shaxslar tomonidan amalga oshiriladi.

Nodavlat ta’lim tashkilotlari litsenziya olingan kundan e’tiboran ta’lim faoliyati bilan shug‘ullanishga haqli bundan ushbu Qonunning 571-moddasida nazarda tutilgan hollar mustasno.

Ta’lim tashkilotlari o‘z faoliyatini ustav va (yoki) boshqa ta’sis hujjatlari asosida yuritadi.

Ta’lim tashkilotlari o‘quv-tarbiya va o‘quv-ilmiy-ishlab chiqarish majmualariga birlashishga haqli.

Ta’lim tashkilotlarida siyosiy partiyalarning tashkiliy tuzilmalarini tashkil etishga yo‘l qo‘yilmaydi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>30-modda. Ta’lim tashkilotlarini tashkil etish, qayta tashkil etish va tugatish</h1>
            <p>Davlat oliy ta’lim, o‘rta maxsus, professional ta’lim muassasalari va ularning filiallari, shuningdek davlat ishtirokidagi oliy, o‘rta maxsus, professional ta’lim tashkilotlari va ularning filiallari O‘zbekiston Respublikasi Prezidentining yoki O‘zbekiston Respublikasi Vazirlar Mahkamasining qarorlari bilan tashkil etiladi.

Iqtisodiyotning va ijtimoiy sohaning oliy ma’lumotli malakali kadrlarga bo‘lgan ehtiyojlarini, shuningdek aholining oliy ta’lim olishga bo‘lgan ehtiyojini qanoatlantirish maqsadida mamlakat hududida xorijiy oliy ta’lim tashkilotlarining filiallari (markazlari, ta’lim kampuslari) va boshqa bo‘linmalari tashkil etilishi mumkin.

Xorijiy oliy ta’lim tashkilotlarining bo‘linmalari O‘zbekiston Respublikasida yuridik shaxs maqomi bilan tashkil etiladi.

Xorijiy oliy ta’lim tashkilotlarining, shuningdek xalqaro tashkilotlarning ta’lim muassasalari filiallari (markazlari, ta’lim kampuslari) va boshqa bo‘linmalari faoliyatini tashkil etish masalalari bo‘yicha O‘zbekiston Respublikasining xalqaro shartnomalariga muvofiq O‘zbekiston Respublikasi Prezidentining yoki Vazirlar Mahkamasining qarorlari qabul qilinishi mumkin.

Kadrlarni qayta tayyorlash va ularning malakasini oshirish bo‘yicha davlat ta’lim muassasalari:

O‘zbekiston Respublikasi Vazirlar Mahkamasi tomonidan institutlar va markazlar shaklida;

tegishli vazirliklar, davlat qo‘mitalari hamda idoralar tomonidan O‘zbekiston Respublikasi Oliy va o‘rta maxsus ta’lim vazirligi bilan kelishilgan holda oliy ta’lim muassasalarining fakultetlari va kurslari shaklida tashkil etiladi.

Davlat umumiy o‘rta va maktabdan tashqari ta’lim muassasalari:

respublika bo‘ysunuvida vazirliklar, davlat qo‘mitalari va idoralari tomonidan Qoraqalpog‘iston Respublikasi Vazirlar Kengashi, viloyatlar va Toshkent shahar hokimliklari bilan kelishgan holda;

Qoraqalpog‘iston Respublikasi, viloyatlar va Toshkent shahri bo‘ysunuvida tegishincha Qoraqalpog‘iston Respublikasi Vazirlar Kengashi, viloyatlar va Toshkent shahar hokimliklari tomonidan O‘zbekiston Respublikasi Xalq ta’limi vazirligi bilan kelishilgan holda;

tumanlar va shaharlar bo‘ysunuvida tumanlar va shaharlar hokimliklari tomonidan O‘zbekiston Respublikasi Xalq ta’limi vazirligi bilan kelishilgan holda tashkil etiladi.

Nodavlat ta’lim muassasalarini tashkil etish ularning ta’sischilari tomonidan amalga oshiriladi.

Ta’lim tashkilotlarini qayta tashkil etish va tugatish qonunchilikda belgilangan tartibda amalga oshiriladi.

Ta’lim tashkilotlarini tashkil etish, qayta tashkil etish va tugatish to‘g‘risidagi ma’lumotlar davlat statistika organlariga, Ta’lim inspeksiyasiga hamda O‘zbekiston Respublikasi Bandlik va mehnat munosabatlari vazirligining hududiy organlariga taqdim etiladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>31-modda. Nodavlat ta’lim tashkilotlari</h1>
            <p>Nodavlat ta’lim tashkilotlari o‘z faoliyatini litsenziya asosida amalga oshiradi, bundan maktabdan tashqari ta’limni, kadrlarni qayta tayyorlash va ularning malakasini oshirishni amalga oshiruvchi ta’lim tashkilotlari mustasno.

Nodavlat ta’lim tashkilotlari litsenziya talablariga va shartlariga muvofiq ta’lim xizmatlari ko‘rsatadi.

Davlat ta’lim standartlari va davlat ta’lim talablariga muvofiq ta’lim xizmatlarini ko‘rsatuvchi nodavlat ta’lim tashkilotlari bitiruvchilarga davlat tomonidan tasdiqlangan namunadagi ta’lim to‘g‘risidagi hujjatlarni beradi.

Kadrlar malakasini oshirish va ularni qayta tayyorlash bo‘yicha nodavlat ta’lim xizmatlarini ko‘rsatuvchi ta’lim tashkilotlari tomonidan bitiruvchilarga davlat tomonidan tasdiqlangan namunadagi ta’lim to‘g‘risidagi hujjat berilishi mumkin. Bunda kadrlar malakasini oshirish va ularni qayta tayyorlash bo‘yicha nodavlat ta’lim xizmatlarini ko‘rsatuvchi ta’lim tashkilotlari belgilangan tartibda attestatsiyadan va davlat akkreditatsiyasidan o‘tishi kerak.

Mustaqil ishlab chiqilgan va litsenziyada ko‘rsatilgan o‘quv dasturlari bo‘yicha ta’lim xizmatlari ko‘rsatadigan nodavlat ta’lim tashkilotlari bitiruvchilarga O‘zbekiston Respublikasida tan olinadigan ta’lim to‘g‘risidagi hujjatlarni beradi.

Nodavlat ta’lim tashkilotlari normativ-huquqiy hujjatlar talablariga muvofiq ta’lim-tarbiya jarayonini tashkil etish uchun zarur shart-sharoitlar yaratish va yuqori kasbiy mahoratga ega bo‘lgan pedagog kadrlar va boshqa kadrlarni jalb qilish bo‘yicha chora-tadbirlar ko‘radi.

Nodavlat ta’lim tashkilotlari tomonidan ishlab chiqilgan o‘quv dasturlari bo‘yicha o‘qitish ta’lim oluvchi yoxud uning ota-onasi yoki boshqa qonuniy vakillari va nodavlat ta’lim tashkiloti o‘rtasida tuziladigan, o‘qitish muddatlari, shartlari va to‘lovlari, tomonlarning huquq va majburiyatlari hamda boshqa shartlar belgilanadigan shartnoma asosida amalga oshiriladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>32-modda. Ta’lim tashkilotining ustavi</h1>
            <p>Ta’lim tashkilotining ustavi ta’lim turlarining o‘ziga xos xususiyatlarini inobatga olgan holda ishlab chiqiladi.

Ta’lim tashkilotining ustavida, qoida tariqasida, quyidagilar ko‘rsatiladi:

ta’lim turi va shakli;

ta’lim tashkilotining maqsad va vazifalari;

o‘quv-tarbiyaviy va ilmiy-metodik ishlarni tashkil etish hamda mazmuni;

ta’lim tashkilotiga qabul qilish tartibi;

ta’lim tashkilotining tuzilmasi, boshqaruv organlari va jamoatchilik tuzilmalari;

ta’lim oluvchilar, pedagog kadrlar, o‘quv-tarbiya ishlari bo‘yicha xodimlar, ma’muriy-boshqaruv xodimlarining maqomi, huquqlari va majburiyatlari;

ta’lim tashkilotining mol-mulki va vositalari;

ta’lim tashkilotini tashkil etish, qayta tashkil etish va tugatish tartibi.

Ta’lim tashkilotining namunaviy ustavi:

umumiy o‘rta ta’lim tashkilotlari, ixtisoslashtirilgan maktablar va maktabdan tashqari ta’lim tashkilotlari uchun — O‘zbekiston Respublikasi Xalq ta’limi vazirligi tomonidan;

Prezident, ijod va ixtisoslashtirilgan maktablar uchun — O‘zbekiston Respublikasi Vazirlar Mahkamasi huzuridagi Prezident, ijod va ixtisoslashtirilgan maktablarni rivojlantirish agentligi tomonidan;

oliy ta’lim muassasalari huzuridagi ixtisoslashtirilgan maktablar, o‘rta maxsus, professional va oliy ta’lim tashkilotlari uchun — O‘zbekiston Respublikasi Oliy va o‘rta maxsus ta’lim vazirligi tomonidan;

kadrlarni qayta tayyorlash va ularning malakasini oshirish bo‘yicha ta’lim tashkilotlari uchun — tegishli vazirliklar, davlat qo‘mitalari va idoralar tomonidan ishlab chiqiladi.

Ta’lim tashkilotining ustavi ta’lim tashkilotining ta’sischilari tomonidan tasdiqlanadi va hududiy tegishlilik bo‘yicha Davlat xizmatlari markazi tomonidan ro‘yxatga olinadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>33-modda. Ta’lim berish tili</h1>
            <p>Ta’lim tashkilotlarida o‘qitish tilidan foydalanish tartibi “Davlat tili haqida”gi O‘zbekiston Respublikasi Qonuni bilan tartibga solinadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>34-modda. Davlat ta’lim standartlari va davlat ta’lim talablari</h1>
            <p>Davlat ta’lim standartlari umumiy o‘rta, o‘rta maxsus, professional hamda oliy ta’lim mazmuni va sifatiga oid talablarni belgilaydi.

Davlat ta’lim talablari:

maktabdan tashqari ta’lim, oliy ta’limdan keyingi ta’lim, shuningdek kadrlarni qayta tayyorlash va ularning malakasini oshirish mazmunini;

ta’lim tuzilmasini va ta’limni amalga oshirish shartlarini;

ta’lim oluvchilarning jismoniy, shaxsiy, intellektual, ilmiy va kasbga oid sifatlari to‘g‘risidagi normalarni belgilaydi.

Maktabgacha ta’lim tashkilotlarida maktabgacha ta’lim va tarbiyaning davlat standarti qo‘llaniladi.

Davlat ta’lim standartlarini va (yoki) davlat ta’lim talablarini bajarish barcha ta’lim tashkilotlari uchun majburiydir, bundan ushbu moddaning beshinchi qismida nazarda tutilgan hollar mustasno.

Nodavlat ta’lim tashkilotlari mustaqil ishlab chiqilgan va litsenziyada yoki xabarnomada ko‘rsatilgan o‘quv dasturlari asosida ta’lim faoliyatini amalga oshirishlari mumkin.

O‘zbekiston Respublikasi Oliy va o‘rta maxsus ta’lim vazirligi davlat ta’lim standartlari, malaka talablari, oliy ta’lim, o‘rta maxsus ta’lim hamda professional ta’limning o‘quv rejalari va o‘quv dasturlari ishlab chiqilishini ta’minlaydi. Ushbu maqsadlar uchun O‘zbekiston Respublikasi Oliy va o‘rta maxsus ta’lim vazirligi tayanch davlat oliy ta’lim va professional ta’lim muassasalarini belgilaydi.

Tayanch davlat oliy ta’lim va professional ta’lim muassasalari kadrlarning talabgorlari ishtirokida davlat ta’lim standartlarini, malaka talablarini, o‘quv rejalari va o‘quv dasturlarini tayyorlashni amalga oshiradi. Davlat ta’lim standartlari kasbiy standartlar asosida ishlab chiqiladi.

O‘zbekiston Respublikasi Xalq ta’limi vazirligi umumiy o‘rta ta’limning davlat ta’lim standartlari ishlab chiqilishini ta’minlaydi.

Oliy, professional, o‘rta maxsus va umumiy o‘rta ta’limning davlat ta’lim standartlari, malaka talablari, o‘quv rejalari va o‘quv dasturlari tegishincha O‘zbekiston Respublikasi Oliy va o‘rta maxsus ta’lim vazirligi, Xalq ta’limi vazirligi hamda O‘zbekiston Respublikasi Vazirlar Mahkamasi huzuridagi Prezident, ijod va ixtisoslashtirilgan maktablarni rivojlantirish agentligi tomonidan tasdiqlanadi. Tegishli vakolatlar berilgan boshqa vazirliklar, davlat qo‘mitalari va idoralar davlat ta’lim standartlarini O‘zbekiston Respublikasi Oliy va o‘rta maxsus ta’lim vazirligi bilan kelishilgan holda ishlab chiqadi hamda tasdiqlaydi.

Davlat ta’lim talablari ta’lim sohasidagi tegishli vakolatli davlat boshqaruvi organlari tomonidan ishlab chiqiladi va tasdiqlanadi.

Jismoniy, aqliy, sensor (sezgi) yoki ruhiy nuqsonlari bo‘lgan shaxslarni o‘qitish maxsus o‘quv dasturlari asosida amalga oshiriladi.

O‘zbekiston Respublikasi Oliy va o‘rta maxsus ta’lim vazirligi davlat oliy ta’lim muassasalariga mustaqil ishlab chiqilgan va tasdiqlangan o‘quv dasturlari, malaka talablari hamda o‘quv rejalari asosida ta’lim xizmatlari ko‘rsatish bo‘yicha vakolatlarni berishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>35-modda. Ta’lim jarayoniga o‘quv rejalari va o‘quv dasturlarini joriy etish</h1>
            <p>O‘quv rejalari va o‘quv dasturlari tegishli ta’lim bosqichlarining maqsad hamda vazifalari asosida ishlab chiqiladi.

Tegishli davlat ta’lim muassasalari va tashkilotlaridagi o‘quv rejalari va o‘quv dasturlarining mazmuni, ularni ishlab chiqish hamda joriy etish tartibi O‘zbekiston Respublikasi Maktabgacha ta’lim vazirligi, Xalq ta’limi vazirligi, O‘zbekiston Respublikasi Vazirlar Mahkamasi huzuridagi Prezident, ijod va ixtisoslashtirilgan maktablarni rivojlantirish agentligi hamda Oliy va o‘rta maxsus ta’lim vazirligi tomonidan belgilanadi.

Umumta’lim fanlarining o‘quv dasturlari shaxsni har tomonlama kamol toptirishga, ta’lim oluvchilarda bilim, malaka, ko‘nikmalarni, saviyani shakllantirishga va ularning qobiliyatini rivojlantirishga qaratilgan bo‘lishi kerak.

Kasbga oid fanlarning o‘quv dasturlari ta’lim oluvchilar tomonidan tegishli kasblar va mutaxassisliklarni egallashga qaratilgan.

Ta’lim jarayoniga o‘quv rejalari va o‘quv dasturlarini joriy etish ta’lim tashkilotlari tomonidan amalga oshiriladi.

O‘quv rejalari va o‘quv dasturlarini joriy etish jarayonida zamonaviy pedagogik texnologiyalar, o‘qitishning innovatsion shakllari va usullari, axborot-kommunikatsiya texnologiyalari qo‘llaniladi.

Ta’lim jarayoniga o‘quv rejalari va o‘quv dasturlarini joriy etish chog‘ida ta’lim tashkilotlari kredit-modul tizimiga asoslangan o‘qitish texnologiyalaridan foydalanishi mumkin.

O‘quv rejasida, qoida tariqasida, ta’lim jarayonining jadvali, o‘qitishning boshlanishi, muddati va davriyligi, o‘quv yillari, choraklar, semestrlar, amaliyot, ta’tillar hamda attestatsiya, ajratilgan haftalar soni, o‘rganiladigan fanlar (modullar) va ularga ajratilgan soatlar (kreditlar) hamda boshqa zarur parametrlar aks ettiriladi.

Professional va oliy ta’lim, kadrlarni qayta tayyorlash va ularning malakasini oshirishga doir o‘quv rejalarda ta’lim oluvchilar uchun amaliyot o‘tash nazarda tutiladi.

Ta’lim oluvchilarning amaliyotni o‘tash tartibi va uni tashkil etish ta’lim sohasidagi vakolatli davlat boshqaruvi organlari tomonidan belgilanadi.

Professional va oliy ta’limga doir o‘quv rejalari davlat ta’lim standartlariga muvofiq mutaxassislik fanlaridan, shuningdek umumkasbiy, matematika, tabiiy-ilmiy, gumanitar va qo‘shimcha fanlardan shakllantiriladi.

O‘quv rejalariga davlat boshqaruvi organlarining topshiriqlariga asosan va ushbu Qonunda nazarda tutilmagan boshqa yo‘l bilan qo‘shimcha fanlarni kiritishga yo‘l qo‘yilmaydi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>36-modda. Ta’lim sohasidagi eksperimental va innovatsion faoliyat</h1>
            <p>Ta’lim sohasidagi eksperimental va innovatsion faoliyat ta’limni modernizatsiya qilish maqsadida amalga oshiriladi hamda yangi ta’lim texnologiyalari va resurslarini ishlab chiqishga, ularni sinovdan o‘tkazishga hamda ta’lim jarayoniga joriy etishga qaratilgan. Eksperimental va innovatsion faoliyatni amalga oshirish tartibi va shartlari O‘zbekiston Respublikasi Vazirlar Mahkamasi tomonidan belgilanadi.

Ta’lim sohasidagi vakolatli davlat boshqaruvi organlari va mahalliy davlat hokimiyati organlari innovatsion o‘quv dasturlari va loyihalarini amalga oshirish hamda ularning natijalarini amaliyotga joriy etish uchun o‘z vakolatlari doirasida shart-sharoitlar yaratadi.

Iqtisodiy rivojlanish va innovatsion faoliyat ehtiyojlaridan kelib chiqqan holda, davlat tomonidan oliy ta’lim tashkilotlari olimlarining ilmiy-tadqiqot ishlari natijalarini ishlab chiqarish jarayoniga joriy etish uchun tegishli shart-sharoitlar, shuningdek oliy ta’lim tashkilotlari ta’lim jarayonining yanada takomillashtirilgan shakllariga bosqichma-bosqich o‘tishi uchun imkoniyatlar yaratiladi.

Ta’lim tashkilotlari eksperimental va innovatsion faoliyatda masofaviy ta’lim texnologiyalaridan foydalanishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>37-modda. Ta’lim tashkilotlari faoliyatining ochiqligi va shaffofligi</h1>
            <p>Ta’lim tashkilotlari faoliyatining ochiqligi va shaffofligi ularning rasmiy veb-saytlarida Internet jahon tarmog‘ida joylashtiriladigan ta’lim tashkilotlari faoliyati to‘g‘risidagi ochiq axborot resurslari bilan ta’minlanadi.

Ta’lim tashkilotlari rasmiy veb-saytlarida quyidagilarni joylashtiradi:

ta’lim tashkilotining ustavi;

ta’lim berish tillari haqida ma’lumot;

davlat ta’lim standartlari, davlat ta’lim talablari;

ta’lim faoliyatining moddiy-texnika ta’minoti haqida ma’lumot;

litsenziya (nodavlat ta’lim tashkilotlari uchun);

ta’lim tashkilotining reytingi;

ta’lim faoliyatini amalga oshirish uchun davlat akkreditatsiyasi to‘g‘risidagi sertifikat;

ilmiy tadqiqotlar yo‘nalishlari va natijalari, shuningdek ularni amalga oshirish uchun ilmiy-tadqiqot bazasi to‘g‘risidagi ma’lumot (oliy ta’lim uchun);

ta’lim oluvchilarga stipendiyalar berish tartibi, ularga ijtimoiy yordam ko‘rsatishning mavjudligi va shartlari to‘g‘risidagi ma’lumot;

vaqtincha yashash joylarining mavjudligi va yashash joylarining soni, shuningdek to‘lov miqdori to‘g‘risidagi ma’lumot;

pedagoglar va ta’lim oluvchilarning soni, shuningdek pedagoglarning ilmiy salohiyati to‘g‘risidagi ma’lumot.

Ta’lim tashkilotlarining rasmiy veb-saytlariga joylashtiriladigan axborotning ishonchligini ta’minlash uchun ta’lim tashkilotlarining rahbarlari shaxsan javobgardir.

Ayrim ta’lim tashkilotlarining faoliyati to‘g‘risidagi axborotdan foydalanish qonunchilikda belgilangan hollarda va tartibda cheklanishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>38-modda. Ta’lim tashkilotlariga o‘qishga qabul qilish</h1>
            <p>Ta’lim tashkilotlariga o‘qishga qabul qilish barcha talabgorlar uchun ta’lim olishga doir teng imkoniyatlarning ta’minlanishi prinsipi asosida amalga oshiriladi, shaxslarning ayrim toifalari bundan mustasno, ularga qonunchilikka muvofiq imtiyozlar berilishi mumkin.

Ta’lim tashkilotlari talabgorlarni va (yoki) ularning ota-onasini yoki boshqa qonuniy vakillarini ustav, litsenziya yoki xabarnoma qabul qilinganligi to‘g‘risidagi tasdiqnoma (nodavlat ta’lim tashkilotlari uchun), davlat akkreditatsiyasi to‘g‘risidagi sertifikat (bundan maktabdan tashqari nodavlat ta’lim xizmatlarini ko‘rsatuvchi nodavlat ta’lim tashkilotlari mustasno), o‘quv dasturi hamda ta’lim faoliyatini tartibga soluvchi boshqa hujjatlar, o‘quvchilarning huquqlari va majburiyatlari bilan tanishtirishi shart.

Jismoniy, aqliy, sensor (sezgi) yoki ruhiy nuqsonlari bo‘lgan bolalar o‘qishga o‘z ota-onasining yoki boshqa qonuniy vakillarining roziligiga va tibbiy-psixologik-pedagogik komissiyaning xulosasiga binoan qabul qilinadi.

Ayrim ta’lim tashkilotlariga (oliy ta’lim muassasalariga, akademik litseylarga, Prezident, ijod, ixtisoslashtirilgan maktablar va boshqalarga) o‘qishga qabul qilish tanlov asosida amalga oshiriladi. Ta’lim tashkilotlariga tanlov asosida o‘qishga qabul qilish chog‘ida tanlov ishtirokchilariga tanlovni o‘tkazish tartibi to‘g‘risidagi axborot taqdim etiladi.

Davlat oliy ta’lim va professional ta’lim muassasalariga o‘qishga qabul qilish davlat granti va (yoki) to‘lov-shartnoma asosida amalga oshiriladi.

Davlat ta’lim muassasalariga o‘qishga qabul qilish tartibi O‘zbekiston Respublikasi Vazirlar Mahkamasi tomonidan belgilanadi.

Nodavlat ta’lim tashkilotlariga o‘qishga qabul qilish tartibi ushbu ta’lim tashkilotlari tomonidan belgilanadi.

Chet ellik fuqarolarni O‘zbekiston Respublikasining davlat ta’lim muassasalariga qabul qilish to‘lov-shartnoma asosida (bundan davlat granti ajratilgan hollar mustasno) amalga oshiriladi.

Oliy ta’lim muassasalariga davlat granti asosida o‘qishga qabul qilish parametrlari O‘zbekiston Respublikasi Prezidenti tomonidan belgilanadi.

Oliy ta’lim muassasalariga o‘qishga qabul qilish chog‘ida imtiyozli kontingent uchun qo‘shimcha qabul parametrlari belgilanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>39-modda. Davlat ta’lim muassasalariga o‘qishga maqsadli qabul qilish</h1>
            <p>Davlat ta’lim muassasalariga o‘qishga maqsadli qabul qilish tegishli hududlarning, sohalar va tarmoqlarning kadrlarga bo‘lgan ehtiyojlaridan kelib chiqqan holda ular uchun belgilangan ta’lim oluvchilarni qabul qilish parametrlari doirasida amalga oshiriladi.

Davlat ta’lim muassasalariga o‘qishga maqsadli qabul qilish kadrlar buyurtmachilari, davlat ta’lim muassasalari va fuqarolar o‘rtasida tuziladigan shartnomalar asosida amalga oshiriladi.

Davlat ta’lim muassasalariga maqsadli qabul qilish tartibida o‘qishga kirish umumiy asoslarda tanlov natijalariga muvofiq amalga oshiriladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>40-modda. Ta’lim to‘g‘risidagi hujjat</h1>
            <p>Akkreditatsiya qilingan ta’lim tashkilotlarining davlat ta’lim standartlariga va davlat ta’lim talablariga muvofiq ta’lim olgan bitiruvchilariga davlat tomonidan tasdiqlangan namunadagi ta’lim to‘g‘risidagi hujjat (shahodatnoma, diplom, sertifikat, guvohnoma) beriladi. Davlat tomonidan tasdiqlangan namunadagi ta’lim to‘g‘risidagi hujjat oilada ta’lim olgan yoki mustaqil ta’lim olgan hamda akkreditatsiya qilingan davlat ta’lim muassasalarining tegishli o‘quv dasturlari bo‘yicha eksternat tartibida yakuniy va davlat attestatsiyasidan o‘tgan shaxslarga ham beriladi.

O‘rta maxsus ta’lim, professional ta’lim hamda oliy ta’lim to‘g‘risidagi diplomga o‘zlashtirilgan fanlar ro‘yxati, ularning hajmlari va fanlar bo‘yicha baholari yozilgan varaqa ilova qilinadi.

Tegishli ilmiy darajani olish uchun dissertatsiya himoya qilgan shaxslarga falsafa doktori (Doctor of Philosophy (PhD) yoki fan doktori (Doctor of Science (DSc) ilmiy darajasi beriladi va davlat tomonidan tasdiqlangan namunadagi diplom topshiriladi.

O‘zbekiston Respublikasining va xorijiy davlatlarning hukumatlari o‘rtasidagi ikki tomonlama bitimlar asosida ta’lim to‘g‘risidagi hujjatlarni o‘zaro tan olish amalga oshirilishi mumkin.

Uzluksiz ta’limning tegishli turini tamomlamagan shaxslarga belgilangan namunadagi ma’lumotnoma beriladi.

Davlat tomonidan tasdiqlangan namunadagi ta’lim to‘g‘risidagi hujjat, shuningdek nodavlat ta’lim tashkilotlari tomonidan beriladigan O‘zbekiston Respublikasida tan olinadigan ta’lim to‘g‘risidagi hujjat uzluksiz ta’limning keyingi turi (darajasi) bo‘yicha o‘qishni davom ettirish yoki tegishli mutaxassislik va kasb bo‘yicha ishlash huquqini beradi.

Xorijiy davlatlarning va O‘zbekiston Respublikasining oliy ta’lim tashkilotlari o‘rtasida tuzilgan shartnoma asosida ularning bitiruvchilariga O‘zbekiston Respublikasi hududida oliy ma’lumot to‘g‘risidagi hujjat sifatida tan olinadigan ikki tomonlama diplom (Double Diploma) berilishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>41-modda. Ta’lim tashkilotlarining reytingi</h1>
            <p>Ta’lim tashkilotlarining reytingi:

ta’lim tashkilotlari o‘rtasida sog‘lom raqobat muhitini shakllantirish;

ilmiy-pedagogik faoliyat darajasining o‘sishini va sifatining oshishini rag‘batlantirish;

pedagog xodimlarning ilmiy salohiyatidan samarali foydalanish;

o‘qitish sifatining yuqori ko‘rsatkichlariga erishish;

mehnat bozorida talab yuqori bo‘lgan malakali kadrlar tayyorlash maqsadlarida belgilanadi.

Reytingni belgilash uchun ta’lim tashkiloti tomonidan taqdim etilgan ma’lumotlarning ishonchliligi uchun ta’lim tashkilotining rahbari shaxsan javobgar bo‘ladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>42-modda. Ta’lim tizimidagi monitoring</h1>
            <p>Ta’lim tizimidagi monitoring ta’limning holatini, ta’lim natijalarining o‘zgarishi sur’atlarini, ta’lim faoliyatini amalga oshirish uchun yaratilgan shart-sharoitlarni o‘rganish va kuzatishni, shuningdek ta’lim oluvchilarning kontingenti to‘g‘risidagi ma’lumotlarni va boshqaruv qarorlari qabul qilinishini tahlil etishni o‘z ichiga oladi.

Ta’lim tashkilotlarining monitoringi Ta’lim inspeksiyasi, ta’lim sohasidagi vakolatli davlat boshqaruvi organlari va ularning hududiy bo‘linmalari tomonidan amalga oshiriladi.

Ta’lim holatining tahlili va uni rivojlantirish istiqbollari to‘g‘risidagi axborot Ta’lim inspeksiyasining, ta’lim sohasidagi vakolatli davlat boshqaruvi organlarining va ular hududiy bo‘linmalarining, shuningdek ta’lim tashkilotlarining rasmiy veb-saytlariga joylashtiriladi.

Ta’lim tizimidagi ma’lumotlar jumlasiga rasmiy statistika ma’lumotlari, ta’lim tizimi monitoringi natijalari, ta’lim sohasidagi vakolatli davlat boshqaruvi organlarining va ular hududiy bo‘linmalarining, mahalliy davlat hokimiyati organlarining hamda ta’lim tashkilotlarining ma’lumotlari kiradi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>43-modda. Ta’lim sohasidagi davlat nazorati</h1>
            <p>Ta’lim sohasidagi davlat nazorati berilayotgan ta’limning mazmuni va sifati davlat ta’lim standartlariga, davlat ta’lim talablari va o‘quv dasturlariga, shuningdek ushbu Qonun talablariga muvofiqligini aniqlash yo‘li bilan amalga oshiriladi.

Ta’lim tashkilotlari ta’lim sifati ustidan nazoratni amalga oshirishda Ta’lim inspeksiyasiga, ta’lim sohasidagi vakolatli davlat boshqaruvi organlariga ko‘maklashadi.

Ta’lim tashkilotlari tomonidan berilayotgan ta’limning mazmuni va sifati ta’lim to‘g‘risidagi qonunchilikka nomuvofiqligi aniqlangan hollarda Ta’lim inspeksiyasi nomuvofiqlikni bartaraf etish yuzasidan ularga taqdimnoma kiritadi. Aniqlangan nomuvofiqlik bartaraf etilmagan taqdirda Ta’lim inspeksiyasi ta’lim tashkilotining davlat akkreditatsiyasi to‘g‘risidagi sertifikatini qonunchilikka muvofiq bekor qilishga haqli.

Ta’lim sifati ustidan nazorat qilish vakolatlariga ega bo‘lmagan organlar tomonidan ta’lim tashkilotlarining ta’lim sifatini, ta’lim jarayoni tashkil etilishini, pedagog xodimlarining mehnat faoliyatini, ta’lim oluvchilarining o‘zlashtirishini tekshirishga yo‘l qo‘yilmaydi.

Ta’lim inspeksiyasi O‘zbekiston Respublikasi Prezidenti huzuridagi Tadbirkorlik subyektlarining huquqlari va qonuniy manfaatlarini himoya qilish bo‘yicha vakilni xabardor qilgan holda nodavlat ta’lim tashkilotlarida ta’lim sifati ustidan nazorat va monitoringni amalga oshiradi.</p>
          </div>
        </>
      )
    },
    {
      title: 'V BOB. Ta’lim tashkilotlari pedagog xodimlarining huquqiy maqomi', 
      content: (
        <>
          <span className="text-sky-600 text-3xl font-bold font-['Montserrat']">5-bob. Ta’lim tashkilotlari pedagog xodimlarining huquqiy maqomi</span>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>44-modda. Pedagogik faoliyat bilan shug‘ullanish huquqi</h1>
            <p>Tegishli ma’lumoti, kasbiy tayyorgarligi bo‘lgan va ma’naviy-axloqiy fazilatlarga ega shaxslar pedagogik faoliyat bilan shug‘ullanish huquqiga ega. Magistraturani tamomlagan shaxslar va diplomli mutaxassislar o‘z mutaxassisligi bo‘yicha pedagogik faoliyat bilan shug‘ullanish huquqiga ega.

Agar qonunchilikda boshqacha qoida nazarda tutilmagan bo‘lsa, pedagogik oliy ma’lumotga ega bo‘lmagan shaxslarga qayta tayyorlash kurslaridan o‘tganidan keyin ta’lim tashkilotlarida (bundan oliy ta’lim tashkilotlari mustasno) pedagogik faoliyat bilan shug‘ullanish huquqi beriladi.

Ishlab chiqarish ta’limi ustalari qayta tayyorlash kurslaridan o‘tmasdan professional ta’lim tashkilotlarida pedagogik faoliyat bilan shug‘ullanishga haqli.

Zarurat bo‘lganda professional ta’lim tashkilotlari ishlab chiqarish ta’limi ustalarini, shuningdek tegishli bilim hamda amaliy ko‘nikmalarga ega bo‘lgan, oliy ma’lumoti bo‘lmagan boshqa mutaxassislarni amaliy va qo‘shimcha mashg‘ulotlarni olib borish uchun jalb etishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>45-modda. Pedagog xodimlarning maqomi va ular faoliyatining kafolatlari</h1>
            <p>Pedagog xodimlarning maqomi jamiyat va davlat tomonidan tan olinadi. Pedagog xodimlar ijtimoiy qo‘llab-quvvatlanadi, o‘z kasbiy faoliyatini amalga oshirishi, ularning ijtimoiy maqomi va obro‘sini oshirish uchun tashkiliy-huquqiy shart-sharoitlar yaratiladi, shuningdek o‘z huquq va qonuniy manfaatlarini amalga oshirish uchun kafolatlar beriladi.

Ta’lim tashkilotlari pedagog xodimlarining huquqlari, sha’ni, qadr-qimmati va ishchanlik obro‘si davlat himoyasi ostida bo‘ladi.

Ta’lim tashkilotlari pedagog xodimlarining kasbiy faoliyatiga aralashishga, ta’lim oluvchilarning bilimlarini to‘g‘ri va xolis baholashga ta’sir ko‘rsatishga, shuningdek ushbu pedagog xodimlarning xizmat majburiyatlarini bajarishiga to‘sqinlik qilishga yo‘l qo‘yilmaydi.

Pedagog xodimlar quyidagi huquqlarga ega:

o‘z sha’ni, qadr-qimmati va ishchanlik obro‘sini himoya qilish;

o‘quv dasturlari doirasida mualliflik dasturlarini ishlab chiqish va joriy etish, o‘qitish uslubiyotini ishlab chiqish, shuningdek tegishli o‘quv fanlari, kurslari, modullaridan foydalanish, ijodiy faollik ko‘rsatish;

zamonaviy pedagogik shakllarni, o‘qitish va tarbiya vositalarini, usullarini erkin tanlash hamda ulardan foydalanish;

kasbiy faoliyatini amalga oshirish uchun ularga zarur shart-sharoitlar yaratilishini talab qilish;

o‘quv, ilmiy va uslubiy yo‘nalishlardagi axborot-resurs markazlarining xizmatlaridan bepul foydalanish;

davlat ta’lim standartlarini, davlat ta’lim talablarini, malaka talablarini, o‘quv rejalari va o‘quv dasturlarini ishlab chiqishda ishtirok etish;

ilmiy, ilmiy-tadqiqot va ijodiy faoliyatni amalga oshirish, eksperimental faoliyatda ishtirok etish, innovatsiyalarni ishlab chiqish va joriy qilish;

ta’lim tashkilotini boshqarishda, shuningdek ta’lim tashkilotining faoliyati bilan bog‘liq masalalarni muhokama qilishda ishtirok etish;

kasaba uyushmalari va nodavlat notijorat tashkilotlari a’zosi bo‘lish, xodimlarining vakillari bo‘lish, fuqarolik jamiyati boshqa institutlari faoliyatida qatnashish;

o‘z kasbiy huquqlarini va umumiy manfaatlarni ifoda etish hamda himoya qilish uchun pedagog xodimlarning jamoat birlashmalariga birlashish;

o‘z kasbiy faoliyatiga aralashuvdan himoyalanish;

davlat sog‘liqni saqlash muassasalarida bepul tibbiy ko‘rikdan o‘tish (davlat ta’lim muassasalari va tashkilotlari uchun);

ta’lim oluvchilarning huquqlari va qonuniy manfaatlarini himoya qilishda ishtirok etish.

Pedagog xodimlar qonunchilikka muvofiq boshqa huquqlarga ham ega bo‘lishi mumkin.

Pedagog xodimlarni ularning lavozim majburiyatlari bilan bog‘liq bo‘lmagan har qanday boshqa ishga jalb qilish taqiqlanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>46-modda. Pedagog xodimlarning majburiyatlari</h1>
            <p>Pedagog xodimlar:

ta’lim-tarbiya jarayoni ishtirokchilarining sha’ni, qadr-qimmati va ishchanlik obro‘sini hurmat qilishi;

o‘quv mashg‘ulotlarini sifatli o‘tkazishi;

axborot-kommunikatsiya texnologiyalaridan, o‘qitish va tarbiyaning ilg‘or hamda innovatsion shakllari va usullaridan foydalanishi;

ta’lim oluvchilarning psixologik va o‘ziga xos xususiyatlarini, jismoniy va ruhiy salomatligini, fiziologik rivojlanishini hisobga olishi, jismoniy, aqliy, sensor (sezgi) yoki ruhiy nuqsonlari bo‘lgan shaxslarni o‘qitish uchun shart-sharoitlar yaratilishiga e’tibor qaratishi;

voyaga yetmagan ta’lim oluvchilar bilan ta’lim-tarbiya ishlarini ularning ota-onasi yoki boshqa qonuniy vakillari bilan hamkorlikda olib borishi;

ta’lim tashkilotining ustaviga va (yoki) boshqa ta’sis hujjatlariga, ichki mehnat tartibi qoidalariga rioya etishi;

o‘z malakasini muntazam ravishda oshirib borishi, egallab turgan lavozimiga muvofiqlik jihatidan davriy attestatsiyadan o‘tishi;

.
tibbiy ko‘rikdan o‘z vaqtida o‘tishi shart.

Pedagog xodimlarning zimmasida qonunchilikka, shuningdek ta’lim oluvchi va ta’lim tashkiloti o‘rtasida tuziladigan shartnomaga muvofiq boshqa majburiyatlar ham bo‘lishi mumkin.

Pedagog xodimlarga pedagogik faoliyatni amalga oshirishda axloq va etika normalariga zid harakatlar sodir etish taqiqlanadi.

Pedagog xodimlarning kiyim-boshiga doir talablar ta’lim tashkilotlari tomonidan belgilanadi.</p>
          </div>
        </>
      )
    },
    {
      title: 'VI BOB. Ta’lim oluvchilarning, ular ota-onasining hamda boshqa qonuniy vakillarining huquq va majburiyatlari', 
      content: (
        <>
          <span className="text-sky-600 text-3xl font-bold font-['Montserrat']">6-bob. Ta’lim oluvchilarning, ular ota-onasining hamda boshqa qonuniy vakillarining huquq va majburiyatlari</span>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>47-modda. Ta’lim oluvchilarning huquqlari</h1>
            <p>Ta’lim oluvchilar quyidagi huquqlarga ega:

bepul asosda umumiy o‘rta, o‘rta maxsus ta’lim va boshlang‘ich professional ta’lim olish;

yashash joyidagi (mikrohududdagi) davlat umumiy o‘rta ta’lim muassasasiga qabul qilinish;

ta’lim olish shakllarini erkin tanlash;

davlat ta’lim standartlari, davlat ta’lim talablari va o‘quv dasturlariga muvofiq sifatli ta’lim olish;

ta’lim olish uchun o‘zining ruhiy xususiyatlari va fiziologik rivojlanishi inobatga olingan holda zarur shart-sharoitlarga ega bo‘lish, shuningdek bepul psixologik-tibbiy xizmatlardan foydalanish;

davlat ta’lim muassasasi tomonidan belgilangan tartibga muvofiq, professional ta’lim va oliy ta’limning davlat ta’lim standartlari talablariga binoan ishlab chiqilgan, o‘zi oladigan ta’limning mazmunini shakllantirishda ishtirok etish;

pedagog xodimlar va ta’lim-tarbiya jarayonining boshqa ishtirokchilari tomonidan hayoti va sog‘lig‘iga qilinadigan har qanday jismoniy hamda ruhiy zo‘ravonlikdan, shaxsi haqoratlanishidan himoyalanish;

ta’lim olish davrida dam olish va boshqa ijtimoiy ehtiyojlar uchun ta’tillar olish;

akademik ta’tillar va stipendiyalar olish, o‘qishni tiklash va o‘qishini boshqa ta’lim tashkilotlariga, bir ta’lim shaklidan, kasbdan, ta’lim yo‘nalishidan, mutaxassisligidan boshqasiga ko‘chirish;

ta’lim tashkilotini boshqarishga doir masalalarni muhokama qilishda ishtirok etish;

ta’lim olish jarayonida ta’lim tashkilotining o‘quv, uslubiy, ilmiy-ishlab chiqarish, madaniy, sport va maishiy obyektlari xizmatlaridan bepul foydalanish;

ta’lim tashkilotining ilmiy-tadqiqot, tajriba-konstruktorlik, ilmiy-texnikaviy, eksperimental va innovatsion faoliyatida ishtirok etish.

Ta’lim oluvchilar qonunchilikka muvofiq boshqa huquqlarga ham ega bo‘lishi mumkin.

Ta’lim tashkilotlarida ta’lim oluvchilarni ta’lim olish bilan bog‘liq bo‘lmagan ishlarga jalb etish taqiqlanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>48-modda. Ta’lim oluvchilarning majburiyatlari</h1>
            <p>Ta’lim oluvchilar:

o‘quv dasturlari asosida bilim, malaka va ko‘nikmalarni o‘zlashtirishi, mashg‘ulotlarga qatnashishi, ularga mustaqil tayyorgarlik ko‘rishi, pedagog xodimlarning topshiriqlarini bajarishi;

ta’lim-tarbiya jarayonining boshqa ishtirokchilariga nisbatan jismoniy va (yoki) ruhiy zo‘ravonlik ishlatmasligi va ularning o‘z majburiyatlarini bajarishiga to‘sqinlik qilmasligi;

ustav (ta’sis hujjati) talablariga, ichki tartib-qoidalariga, vaqtincha yashash joylari qoidalariga va ta’lim faoliyatini tashkil etish hamda amalga oshirishga oid boshqa ichki hujjatlar talablariga rioya etishi;

axloqiy, ma’naviy va jismoniy kamol topishga hamda o‘z dunyoqarashini kengaytirishga intilishi;

ta’lim-tarbiya jarayoni ishtirokchilarining sha’ni, qadr-qimmati va ishchanlik obro‘sini hurmat qilishi;

ta’lim tashkilotining mol-mulkini, moddiy va madaniy boyliklarini asrashi shart.

Ta’lim oluvchilarning zimmasida qonunchilikka muvofiq boshqa majburiyatlar ham bo‘lishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>49-modda. Ta’lim oluvchilarning kiyim-boshiga nisbatan qo‘yiladigan talablar</h1>
            <p>Ta’lim tashkilotlarida ta’lim oluvchilarning kiyim-boshiga doir talablar O‘zbekiston Respublikasi Vazirlar Mahkamasi tomonidan belgilanadi.

Maktabdan tashqari ta’lim, kadrlar malakasini oshirish va ularni qayta tayyorlash turlari bo‘yicha nodavlat ta’lim xizmatlarini ko‘rsatuvchi nodavlat ta’lim tashkilotlari ta’lim oluvchilarning kiyim-boshiga doir talablarni mustaqil belgilashga haqli.

Ta’lim oluvchilarning ayrim toifalari O‘zbekiston Respublikasi Davlat budjeti mablag‘lari hisobidan kiyim-bosh bilan ta’minlanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>50-modda. Ta’lim tashkilotlarida ta’lim oluvchilarni vaqtincha yashash joylari bilan ta’minlash</h1>
            <p>Kunduzgi ta’lim shaklidagi ta’lim tashkilotida ta’lim oluvchilarga, shuningdek sirtqi ta’lim shaklida yakuniy va oraliq attestatsiya davrida vaqtincha yashash joylari, ular mavjud bo‘lgan taqdirda beriladi.

Vaqtincha yashash joylari ta’lim oluvchilarga ta’lim tashkiloti tomonidan belgilangan tartibga muvofiq beriladi.

Vaqtincha yashash joylariga muhtojlar mavjud bo‘lgan hollarda, ushbu joylardan boshqa maqsadlarda foydalanishga yo‘l qo‘yilmaydi.

Vaqtincha yashash joylaridan foydalanish uchun ta’lim tashkiloti bilan tuzilgan shartnomaga muvofiq haq to‘lanadi.

Vaqtincha yashash joyidan foydalanganlik uchun to‘lov miqdori ta’lim tashkiloti tomonidan belgilanadi.

Davlat ta’lim muassasalari ayrim turdagi ta’lim oluvchilar uchun vaqtincha yashash joyidan foydalanganlik uchun to‘lov qiymatini kamaytirishga yoki ularni to‘lovdan to‘liq ozod qilishga haqli. Yetim bolalar va ota-ona qaramog‘idan mahrum bo‘lgan bolalar, shuningdek o‘qitish davrida yetim bo‘lib qolgan bolalar, jismoniy, aqliy, sensor (sezgi) yoki ruhiy nuqsonlari bo‘lgan bolalar (shaxslar) vaqtincha yashash joyidan foydalanganlik uchun haq to‘lashdan ozod qilinadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>51-modda. Voyaga yetmagan ta’lim oluvchilar ota-onasining hamda boshqa qonuniy vakillarining huquq va majburiyatlari</h1>
            <p>Voyaga yetmagan ta’lim oluvchilarning ota-onasi va boshqa qonuniy vakillari bolaning o‘qishi, tarbiyalanishi, jismoniy, ma’naviy va intellektual rivojlanishi uchun mas’uldir.

Mahalliy davlat hokimiyati organlari, fuqarolarning o‘zini o‘zi boshqarish organlari va ta’lim tashkilotlari voyaga yetmagan ta’lim oluvchilarni tarbiyalashda, ularning jismoniy hamda ruhiy sog‘lig‘ini muhofaza qilish va mustahkamlashda, shuningdek individual qobiliyatlarini rivojlantirishda ularning ota-onasiga hamda boshqa qonuniy vakillariga ko‘maklashadi.

Voyaga yetmagan ta’lim oluvchilarning ota-onasi va boshqa qonuniy vakillari quyidagi huquqlarga ega:

jismoniy, aqliy, sensor (sezgi) yoki ruhiy nuqsonlari bo‘lgan bolalarga, shuningdek uzoq vaqt davolanishga muhtoj bo‘lgan bolalarga oilada ta’lim olish imkoniyatini berish;

oilada ta’lim olayotgan bolaning fikrini inobatga olgan holda uning o‘qishini ta’limning har qanday bosqichida ta’lim tashkilotida davom ettirish to‘g‘risida qaror qabul qilish;

ta’lim tashkilotlari bilan hamkorlik qilish, ta’lim-tarbiya jarayonini takomillashtirish, moddiy-texnika bazasini rivojlantirish, ta’lim tashkilotlariga xayriya yordami ko‘rsatish bo‘yicha takliflar kiritish;

ta’lim tashkilotining ustavi va (yoki) boshqa ta’sis hujjati, litsenziyasi, davlat akkreditatsiyasi to‘g‘risidagi sertifikati, davlat ta’lim standartlari, davlat ta’lim talablari, malaka talablari, o‘quv rejalari va o‘quv dasturlari bilan tanishish;

ta’limning mazmuni, qo‘llanilayotgan ta’lim va tarbiya usullari, ta’lim texnologiyalari bilan, shuningdek o‘z bolalarining o‘quv fanlarini o‘zlashtirishi natijalari bilan tanishish;

ta’lim oluvchilarning huquqlari va qonuniy manfaatlarini himoya qilish;

ta’lim tashkilotini boshqarishga doir masalalarni muhokama qilishda ishtirok etish.

Voyaga yetmagan ta’lim oluvchilarning ota-onasi va boshqa qonuniy vakillari qonunchilikka muvofiq boshqa huquqlarga ham ega bo‘lishi mumkin.

Voyaga yetmagan ta’lim oluvchilarning ota-onasi va boshqa qonuniy vakillari:

o‘z bolalarini insonparvarlik, vatanparvarlik, mehnatsevarlik, ma’naviy, milliy va umuminsoniy qadriyatlarni hurmat qilish ruhida tarbiyalashi;

bolalarining umumiy o‘rta, o‘rta maxsus ta’lim yoki boshlang‘ich professional ta’lim olishini ta’minlashi;

bolalarining o‘quv mashg‘ulotlariga qatnashishini ta’minlash va o‘zlashtirishi ustidan nazoratni amalga oshirish;

o‘z bolalarining intellektual, ma’naviy va jismoniy rivojlanishi uchun shart-sharoitlar yaratishi;

ta’lim tashkilotining ta’lim-tarbiya jarayonini tartibga soluvchi ichki tartib-qoidalariga rioya etishi;

jismoniy va yuridik shaxslar bilan munosabatlarda, shu jumladan sudda maxsus vakolatlarsiz o‘z bolalarining ta’lim sohasidagi huquqlari va qonuniy manfaatlarini himoya qilishi;

ta’lim-tarbiya jarayoni ishtirokchilarining sha’ni va qadr-qimmatini hurmat qilishi shart.

Voyaga yetmagan ta’lim oluvchilarning ota-onasi va boshqa qonuniy vakillari zimmasida qonunchilikka muvofiq boshqa majburiyatlar ham bo‘lishi mumkin.</p>
          </div>
        </>
      )
    },
    {
      title: 'VII BOB. Ta’lim-tarbiya jarayoni ishtirokchilarini ijtimoiy himoya qilish', 
      content: (
        <>
          <span className="text-sky-600 text-3xl font-bold font-['Montserrat']">7-bob. Ta’lim-tarbiya jarayoni ishtirokchilarini ijtimoiy himoya qilish</span>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>52-modda. Ta'lim oluvchilarni ijtimoiy himoya qilish</h1>
            <p>Ta’lim tashkilotlarida ta’lim oluvchilar qonunchilikka muvofiq imtiyozlar, stipendiyalar va vaqtincha yashash joylari bilan ta’minlanadi.

To‘lov-shartnoma asosida ta’lim oluvchilarga imtiyozli bank kreditlari berilishi mumkin.

Nodavlat ta’lim tashkilotlari ta’lim oluvchilarni ijtimoiy himoya qilishni qonunchilikka, o‘z ustaviga va (yoki) boshqa ta’sis hujjatiga muvofiq amalga oshiradi.

Davlat ijtimoiy himoya qilishni ta’minlash maqsadida kam ta’minlangan oilalardagi bolalar, jismoniy, aqliy, sensor (sezgi) yoki ruhiy nuqsonlari bo‘lgan bolalar (shaxslar) uchun, shuningdek mazkur toifadagi ta’lim oluvchilarning kasbiy o‘sishi uchun shart-sharoitlar yaratadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>53-modda. Ta’lim tashkilotlarining xodimlarini ijtimoiy himoya qilish</h1>
            <p>Ta’lim tashkilotlarining xodimlarini ijtimoiy himoya qilish davlat tomonidan kafolatlanadi.

Ta’lim tashkilotlarining pedagog xodimlariga qisqartirilgan ish vaqti davomiyligi belgilanadi, haq to‘lanadigan har yilgi uzaytirilgan ta’til va boshqa imtiyozlar va kafolatlar taqdim etiladi.

Ta’lim tashkilotlarining pedagog va boshqa xodimlariga sanitariya-gigiyenaga oid, epidemiyaga qarshi hamda profilaktika choralari bilan amalga oshiriladigan sog‘liqni saqlash kafolatlanadi.

Ta’lim tashkilotlari mehnatga haq to‘lash uchun mavjud bo‘lgan mablag‘lar doirasida mustaqil ravishda ish haqiga, lavozim maoshlariga tabaqalashtirilgan ustamalar belgilashga va mehnatga haq to‘lash hamda uni rag‘batlantirishning turli shakllarini qo‘llashga haqli.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>54-modda. Yetim bolalarni va ota-onasining yoki boshqa qonuniy vakillarining qaramog‘idan mahrum bo‘lgan bolalarni o‘qitish va ularning to‘liq ta’minoti</h1>
            <p>Yetim bolalarni va ota-onasining yoki boshqa qonuniy vakillarining qaramog‘idan mahrum bo‘lgan bolalarni o‘qitish va ularning to‘liq ta’minoti O‘zbekiston Respublikasi Davlat budjeti mablag‘lari hisobidan amalga oshiriladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>55-modda. Jismoniy, aqliy, sensor (sezgi) yoki ruhiy nuqsonlari bo‘lgan bolalarni (shaxslarni) o‘qitish hamda tarbiyalash</h1>
            <p>Davlat jismoniy, aqliy, sensor (sezgi) yoki ruhiy nuqsonlari bo‘lgan bolalarning (shaxslarning) davlat ixtisoslashtirilgan ta’lim muassasalarida, umumiy o‘rta, o‘rta maxsus, professional ta’lim muassasalarida inklyuziv shaklda bepul umumiy o‘rta, o‘rta maxsus, professional va maktabdan tashqari ta’lim olishini ta’minlaydi.

Jismoniy, aqliy, sensor (sezgi) yoki ruhiy nuqsonlari bo‘lgan, shuningdek uzoq vaqt davolanishga muhtoj bo‘lgan bolalarni o‘qitish hamda tarbiyalash uchun davlat ixtisoslashtirilgan ta’lim muassasalari tashkil etiladi. Ta’lim oluvchilarni ushbu ta’lim muassasalariga yuborish va ulardan chetlatish ota-onasining yoki boshqa qonuniy vakillarining roziligi bilan tibbiy-psixologik-pedagogik komissiyaning xulosasiga binoan amalga oshiriladi.

Davlat ixtisoslashtirilgan ta’lim muassasalarida ta’lim oluvchilar davlat ta’minotida bo‘ladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>56-modda. Ijtimoiy reabilitatsiyaga muhtoj bo‘lgan bolalarni (shaxslarni) o‘qitish va tarbiyalash</h1>
            <p>Alohida sharoitlarda o‘qitish va tarbiyalanishga muhtoj bo‘lgan bolalar (shaxslar) uchun ularning ta’lim olishini, kasbiy tayyorgarligini va ijtimoiy reabilitatsiya qilinishini ta’minlaydigan ixtisoslashtirilgan o‘quv-tarbiya muassasalari tashkil etiladi.

Ozodlikdan mahrum qilish tarzida jazoni ijro etish muassasalarida saqlanayotgan bolalarning (shaxslarning) ta’lim olishi, tarbiyalanishi va mustaqil ta’lim olishi uchun sharoitlar yaratiladi.</p>
          </div>
        </>
      )
    },
    {
      title: 'VIII BOB. Nodavlat ta’lim tashkilotlari faoliyatini litsenziyalash, ta’lim tashkilotlarini attestatsiyadan va davlat akkreditatsiyasidan o‘tkazish. Xorijiy davlatda olingan ta’lim to‘g‘risidagi hujjatni tan olish, ta’lim sohasidagi hujjatlarga apostil qo‘yish', 
      content: (
        <>
          <span className="text-sky-600 text-3xl font-bold font-['Montserrat']">8-bob. Nodavlat ta’lim tashkilotlari faoliyatini litsenziyalash, ta’lim tashkilotlarini attestatsiyadan va davlat akkreditatsiyasidan o‘tkazish. Xorijiy davlatda olingan ta’lim to‘g‘risidagi hujjatni tan olish, ta’lim sohasidagi hujjatlarga apostil qo‘yish</span>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>57-modda. Nodavlat ta’lim tashkilotlarining faoliyatini litsenziyalash</h1>
            <p>Nodavlat ta’lim tashkilotlarining faoliyatini litsenziyalash “Litsenziyalash, ruxsat berish va xabardor qilish tartib-taomillari to‘g‘risida”gi O‘zbekiston Respublikasi Qonuni bilan tartibga solinadi.

Nodavlat ta’lim tashkilotlariga litsenziya berish va qayta rasmiylashtirish, litsenziyaning amal qilishini to‘xtatib turish, shuningdek litsenziyani bekor qilish yoki uni bekor qilish to‘g‘risidagi ariza bilan sudga murojaat qilish qonunchilikda belgilangan tartibda Ta’lim inspeksiyasi tomonidan amalga oshiriladi.

maktabgacha ta’lim va tarbiya (bundan oilaviy maktabgacha ta’lim mustasno);

umumiy o‘rta va o‘rta maxsus ta’lim;

professional ta’lim;

oliy ta’lim;

oliy ta’limdan keyingi ta’lim.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>57-modda. Nodavlat ta’lim faoliyatini xabardor qilish tartibida amalga oshirish</h1>
            <p>Ta’limning quyidagi turlari Ta’lim inspeksiyasini belgilangan tartibda xabardor

qilish orqali amalga oshiriladi:
maktabdan tashqari ta’lim;

kadrlarni qayta tayyorlash va ularning malakasini oshirish.

Oilaviy nodavlat maktabgacha ta’lim tashkiloti shaklida ta’lim xizmatlari ko‘rsatishga doir faoliyatini amalga oshirish uchun O‘zbekiston Respublikasi Maktabgacha ta’lim vazirligiga belgilangan tartibda xabarnoma yuboriladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>58-modda. Ta’lim tashkilotlarini attestatsiyadan va davlat akkreditatsiyasidan o‘tkazish</h1>
            <p>O‘zbekiston Respublikasi hududida faoliyat ko‘rsatayotgan maktabgacha, umumiy o‘rta, o‘rta maxsus, professional va oliy ta’lim tashkilotlari, shuningdek oliy ta’limdan keyingi ta’limni amalga oshiruvchi ta’lim tashkilotlari davlat ta’lim standartlariga, davlat ta’lim talablariga hamda o‘quv dasturlariga muvofiqlik jihatidan attestatsiyadan va davlat akkreditatsiyasidan o‘tkaziladi.

Bitiruvchilarga davlat tomonidan tasdiqlangan namunadagi ta’lim to‘g‘risidagi hujjatlarni beruvchi, kadrlar malakasini oshirish va ularni qayta tayyorlash bo‘yicha nodavlat ta’lim tashkilotlari attestatsiyadan va davlat akkreditatsiyasidan o‘tadi.

Ta’lim tashkilotlarini attestatsiyadan va davlat akkreditatsiyasidan o‘tkazish besh yil muddatga amalga oshiriladi.

Ta’lim tashkilotlarini attestatsiyadan va davlat akkreditatsiyasidan o‘tkazish ta’lim tashkilotlarining arizasiga ko‘ra Ta’lim inspeksiyasi tomonidan amalga oshiriladi. Ariza akkreditatsiya muddati tugashidan uch oy oldin beriladi.

Attestatsiya ikki bosqichda — ta’lim tashkilotlari faoliyatini ichki baholash va tashqi baholash bosqichlarida amalga oshiriladi.

Ichki baholash ta’lim tashkilotining o‘zini o‘zi baholashidir.

Tashqi baholash ichki baholash o‘tkazilganidan keyin Ta’lim inspeksiyasi tomonidan amalga oshiriladigan baholashdir.

O‘zbekiston Respublikasi Prezidenti yoki O‘zbekiston Respublikasi Vazirlar Mahkamasining qarorlari asosida tashkil etilgan, shuningdek vazirliklar, davlat qo‘mitalari, idoralari va mahalliy davlat hokimiyati organlari tomonidan tashkil etilgan ta’lim tashkilotlari tashkil etilgan kundan e’tiboran besh yil mobaynida akkreditatsiya qilingan hisoblanadi.

Nodavlat ta’lim tashkilotlari litsenziya olingan kundan e’tiboran besh yil davomida akkreditatsiyadan o‘tgan deb hisoblanadi, bu muddat tugagach, ushbu Qonunda belgilangan tartibda attestatsiya va akkreditatsiyadan o‘tkaziladi.

Ta’lim tashkilotlarini davlat akkreditatsiyasidan o‘tkazish maqsadida Ta’lim inspeksiyasi huzurida doimiy faoliyat ko‘rsatuvchi davlat akkreditatsiya komissiyasi tuziladi.

Davlat akkreditatsiyasi ta’lim tashkilotining attestatsiyasi asosida amalga oshiriladi. Doimiy faoliyat ko‘rsatuvchi davlat akkreditatsiya komissiyasi ta’lim tashkilotining maqomini va uning faoliyati davlat ta’lim standartlariga, davlat ta’lim talablariga va o‘quv dasturlariga muvofiqligini aniqlaydi.

Ta’lim tashkilotining davlat akkreditatsiyasi to‘g‘risida ijobiy qaror qabul qilingan taqdirda, unga davlat akkreditatsiyasining amal qilish muddati ko‘rsatilgan holda belgilangan namunadagi sertifikat beriladi.

Ta’lim tashkiloti qayta tashkil etilgan yoki tugatilgan hollarda davlat akkreditatsiyasi to‘g‘risidagi sertifikatning amal qilishi Ta’lim inspeksiyasining qarori bilan tugatiladi.

Ta’lim to‘g‘risidagi qonunchilikning talablari yoki sertifikatda ko‘rsatilgan shartlar buzilganligi aniqlangan va aniqlangan qoidabuzarliklar ta’lim tashkiloti tomonidan bartaraf etilmagan hollarda Ta’lim inspeksiyasi tomonidan davlat akkreditatsiyasi to‘g‘risidagi sertifikatning amal qilishini bekor qilish xaqida qaror qabul qilinadi.

Davlat akkreditatsiyasidan o‘tgan ta’lim tashkilotlari Ta’lim tashkilotlarining reyestriga kiritiladi va bu haqdagi ma’lumotlar Ta’lim inspeksiyasining rasmiy veb-saytiga joylashtiriladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>59-modda. Ta’lim tashkilotlarining faoliyatini ichki va tashqi baholashdan o‘tkazish</h1>
            <p>Ta’lim tashkilotlarining faoliyati tashqi baholashdan o‘tkazilishidan oldin ular Ta’lim inspeksiyasi tomonidan ishlab chiqilgan attestatsiyadan o‘tkazish mezonlari va ko‘rsatkichlari asosida o‘z faoliyatini mustaqil ravishda ichki baholashdan o‘tkazadi.

Ta’lim tashkilotlari o‘z faoliyati tashqi baholashdan o‘tkazilishidan ikki oy oldin ichki baholash natijalarini Ta’lim inspeksiyasiga taqdim etadi.

Ta’lim inspeksiyasi ta’lim tashkilotining faoliyatini ichki baholash yakunlarini o‘rganadi va ulardan ta’lim tashkilotining faoliyatini tashqi baholash jarayonida foydalanadi.

Ta’lim tashkiloti rahbari ichki baholash natijalarining ishonchliligi uchun javobgar bo‘ladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>60-modda. Xorijiy davlatda olingan ta’lim to‘g‘risidagi hujjatni tan olish</h1>
            <p>Xorijiy davlatda 1992-yil 1-yanvardan keyin olingan ta’lim to‘g‘risidagi hujjat tan olish jarayonidan o‘tkazilganidan keyin O‘zbekiston Respublikasining butun hududida qonuniy kuchga ega hujjat sifatida tan olinadi.

Xorijiy davlatda olingan ta’lim to‘g‘risidagi hujjatni tan olish Ta’lim inspeksiyasi tomonidan amalga oshiriladi.

Xorijiy davlatda olingan ta’lim to‘g‘risidagi hujjatni tan olish tartibi O‘zbekiston Respublikasi Vazirlar Mahkamasi tomonidan belgilanadi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>61-modda. Ta’lim sohasidagi rasmiy hujjatlarga apostil qo‘yish</h1>
            <p>Ta’lim sohasidagi rasmiy hujjatlarga apostil hujjatni tasdiqlagan shaxs imzosining haqiqiyligini, shuningdek muhr yoki shtampning bosma izi haqiqiysiga muvofiqligini tasdiqlash maqsadida qo‘yiladi.

Apostilga qo‘yilgan imzo, muhr yoki shtamp qo‘shimcha ravishda tasdiqlashni talab etmaydi.

Ta’lim tashkilotlari tomonidan berilgan rasmiy hujjatlarga apostil qo‘yish Ta’lim inspeksiyasi tomonidan amalga oshiriladi.</p>
          </div>
        </>
      )
    },
    {
      title: 'IX BOB. Ta’limni moliyalashtirish va davlat tomonidan qo‘llab-quvvatlash', 
      content: (
        <>
          <span className="text-sky-600 text-3xl font-bold font-['Montserrat']">9-bob. Ta’limni moliyalashtirish va davlat tomonidan qo‘llab-quvvatlash</span>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>62-modda. Ta’lim tashkilotlarini moliyalashtirish</h1>
            <p>Davlat ta’lim muassasalarini moliyalashtirish O‘zbekiston Respublikasining respublika budjetidan, Qoraqalpog‘iston Respublikasi budjetidan, viloyatlar va Toshkent shahar mahalliy budjetlaridan, tumanlar va shaharlar budjetlaridan, kadrlar buyurtmachilarining mablag‘lari hisobidan, shuningdek budjetdan tashqari mablag‘lar hamda qonunchilikda taqiqlanmagan boshqa manbalar hisobidan amalga oshiriladi.

Nodavlat ta’lim tashkilotlarini moliyalashtirish muassislarning, kadrlar buyurtmachilarining pul va moddiy mablag‘lari hamda qonunchilikda taqiqlanmagan boshqa manbalar hisobidan amalga oshiriladi.

Davlat ta’lim muassasalari ustavida belgilangan vazifalarga muvofiq pulli ta’lim xizmatlari va boshqa xizmatlar ko‘rsatish, shuningdek tadbirkorlik faoliyati bilan shug‘ullanish huquqiga ega.

Pulli ta’lim xizmatlarini ko‘rsatish davlat ta’lim muassasalarining asosiy faoliyatiga to‘sqinlik qilmasligi kerak.

Davlat ta’lim muassasalarida qo‘shimcha ta’lim xizmatlari ko‘rsatganlik uchun haq undirish tartibi ular tomonidan mustaqil ravishda belgilanadi.

Davlat ta’lim muassasalari pulli ta’lim xizmatlari va boshqa xizmatlar ko‘rsatish hamda tadbirkorlik faoliyati bilan shug‘ullanish hisobidan olingan pul mablag‘larini mustaqil ravishda tasarruf etishga haqli.

Ta’lim tashkilotlarini moliyalashtirishning qo‘shimcha manbalari quyidagilardan iborat:

shartnomalar asosida, shu jumladan chet ellik jismoniy yoki yuridik shaxslar bilan tuzilgan shartnomalar asosida kadrlarni tayyorlash, qayta tayyorlash va ularning malakasini oshirish hisobidan tushgan mablag‘lar;

jismoniy va yuridik shaxslarning buyurtmalari asosida ilmiy-tadqiqot, o‘quv-uslubiy va qonunda taqiqlanmagan boshqa ishlarni bajarish hisobidan tushgan mablag‘lar;

ta’lim tashkilotlari tomonidan ishlab chiqilgan mahsulotni, bajarilgan ishlarni va ko‘rsatilgan xizmatlarni realizatsiya qilishdan olingan daromadlar;

binolar, inshootlar va asbob-uskunalarni ijaraga berish hisobidan tushgan mablag‘lar;

ta’lim tashkilotlarining bo‘sh turgan pul mablag‘larini bank muassasalariga depozitlarga joylashtirish hisobidan olingan pul mablag‘lari (foizlar);

davlat va xo‘jalik boshqaruvi organlari, shuningdek mahalliy davlat hokimiyati organlari tomonidan ajratiladigan mablag‘lar;

bank kreditlari va ssudalari;

jismoniy va yuridik shaxslarning xayriya mablag‘lari.

Maktabgacha, umumiy o‘rta, o‘rta maxsus ta’limda va boshlang‘ich professional ta’limda ajratiladigan mablag‘lar summalari O‘zbekiston Respublikasi Moliya vazirligi tomonidan belgilanadi hamda ushbu mablag‘lar tarbiyalanuvchilar va ta’lim oluvchilarning o‘qish joyidagi ta’lim tashkilotlariga yo‘naltiriladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>63-modda. Ta’limni rivojlantirish jamg‘armalari</h1>
            <p>Ta’limni rivojlantirish jamg‘armalari qonunchilikda belgilangan tartibda davlat muassasalari hamda tashkilotlarining, yuridik va jismoniy shaxslarning, shu jumladan chet ellik yuridik va jismoniy shaxslarning badallari hamda ajratmalari, shuningdek qonunchilikda taqiqlanmagan boshqa manbalar hisobidan tashkil etilishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>64-modda. Ta’lim sohasidagi davlat-xususiy sheriklik</h1>
            <p>Ta’lim sohasidagi davlat-xususiy sheriklik davlat va xususiy sheriklarning muayyan muddatga yuridik jihatdan rasmiylashtirilgan, davlat-xususiy sheriklik loyihasini amalga oshirish uchun o‘z resurslarini birlashtirishiga asoslangan hamkorlikdir.

Nodavlat ta’lim tashkilotlari ta’lim sohasidagi davlat-xususiy sheriklik asosida tashkil etilishi mumkin.

Ta’lim sohasidagi davlat-xususiy sheriklik “Davlat-xususiy sheriklik to‘g‘risida”gi O‘zbekiston Respublikasi Qonuni prinsiplari, normalari va qoidalariga muvofiq amalga oshiriladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>65-modda. Ta’lim sohasiga investitsiyalarni jalb etish</h1>
            <p>Davlat ta’lim sohasini, ta’lim tashkilotlari faoliyatini rivojlantirishga, shuningdek investorlarning, shu jumladan chet ellik investorlarning ushbu sohadagi huquqlari va qonuniy manfaatlarini himoya qilishga qaratilgan investitsiyalarni jalb etish uchun qulay ijtimoiy-iqtisodiy, tashkiliy-huquqiy sharoitlar yaratilishini ta’minlaydi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>66-modda. Ta’lim tashkilotlarining mol-mulki</h1>
            <p>Ta’lim tashkilotlari o‘z mulkiga, xo‘jalik yurituvidagi yoki operativ boshqaruvidagi mulkka ega bo‘lishi kerak.

Davlat ta’lim muassasalarining operativ boshqaruvida yoki xo‘jalik yurituvida bo‘lgan obyektlarning (binolar, inshootlar, qurilayotgan binolar va inshootlarning, o‘quv, ishlab chiqarish va ijtimoiy infratuzilmalarning, ta’lim oluvchilar vaqtincha turar joy binolarining, klinik bazalar va boshqa ko‘chmas mulk obyektlarining, shu jumladan ta’lim kampuslariga kiradigan mulk obyektlarining) xususiylashtirilishiga yo‘l qo‘yilmaydi.

Ta’lim tashkilotlari qayta tashkil etilgan hollarda ularning mol-mulki yangi tashkil etilgan ta’lim tashkilotiga huquqiy vorislik asosida o‘tkaziladi.

Ta’lim tashkilotlari tugatilganda ularga tegishli mol-mulk kreditorlarning talablari qanoatlantirilgandan so‘ng, agar qonunchilikda boshqacha qoida nazarda tutilmagan bo‘lsa, muassislarga (ishtirokchilarga) qaytariladi.</p>
          </div>
        </>
      )
    },
    {
      title: 'X BOB. Ta’lim sohasidagi xalqaro hamkorlik', 
      content: (
        <>
          <span className="text-sky-600 text-3xl font-bold font-['Montserrat']">10-bob. Ta’lim sohasidagi xalqaro hamkorlik</span>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>67-modda. Ta’lim tashkilotlarining xalqaro hamkorligi</h1>
            <p>Ta’lim tashkilotlari quyidagilar vositasida tegishli xorijiy mamlakatlarning ta’lim

muassasalari va tashkilotlari bilan xalqaro hamkorlikni amalga oshiradi:
ta’lim muammolari yuzasidan ilmiy-texnik hamkorlikni rivojlantirish;

qo‘shma fakultetlar, o‘quv markazlari va ilmiy laboratoriyalar tashkil etish;

xalqaro darajadagi birgalikdagi ta’lim hamda ilmiy-tadqiqot loyihalari va dasturlarini tayyorlash;

hamkorlikda fundamental hamda amaliy ilmiy-tadqiqot loyihalarini amalga oshirish;

ilmiy-amaliy seminarlar, konferensiyalar va simpoziumlar o‘tkazish;

talabalar, magistrlar, doktorantlar, o‘qituvchilar va ilmiy xodimlar almashinishini amalga oshirish;

ikki tomonlama diplomlar (Double Diploma) dasturlarini joriy etish;

qonunchilikka muvofiq boshqa tadbirlar.

Ta’lim tashkilotlari qonunchilikka muvofiq xorijiy davlatlarning ta’lim muassasalari va tashkilotlari bilan hamkorlikda kadrlar tayyorlashni amalga oshirishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>68-modda. Ta’lim sohasidagi xalqaro hamkorlik</h1>
            <p>Ta’lim sohasidagi xalqaro hamkorlik O‘zbekiston Respublikasining xalqaro shartnomalari va qonunchilikka muvofiq amalga oshiriladi.

Ta’lim sohasidagi vakolatli davlat boshqaruvi organlari: xorijiy davlatlarning tegishli vakolatli organlari, ta’lim muassasalari bilan hamkorlik qiladi;

O‘zbekiston Respublikasida doimiy yashovchi fuqarolarni xorijiy davlatlarning ta’lim muassasalariga o‘qish uchun yuboradi;

pedagog xodimlar va ta’lim oluvchilar almashinuvini amalga oshiradi;

rahbar hamda pedagog xodimlarning xorijiy davlatlarda tayyorlash, qayta tayyorlash va malakasini oshirishni tashkil etadi;

o‘z xodimlari hamda mutaxassislarini xalqaro konferensiyalarga va stajirovkalarga yuborish, ularning xalqaro loyihalar hamda ilmiy tadqiqotlarda ishtirok etishini qo‘llab-quvvatlaydi.

Ta’lim sohasidagi vakolatli davlat boshqaruvi organlari qonunchilikka muvofiq ta’lim sohasidagi xalqaro hamkorlikni rivojlantirish bo‘yicha boshqa tadbirlarni ham amalga oshirishi mumkin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>69-modda. Xorijda ta’lim olish</h1>
            <p>O‘zbekiston Respublikasida doimiy yashovchi fuqarolar O‘zbekiston Respublikasining xalqaro shartnomalariga muvofiq yoki yakka tartibda xorijda ta’lim olish huquqiga ega.</p>
          </div>
        </>
      )
    },
    {
      title: 'XI BOB. Yakunlovchi qoidalar', 
      content: (
        <>
          <span className="text-sky-600 text-3xl font-bold font-['Montserrat']">11-bob. Yakunlovchi qoidalar</span>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>70-modda. Nizolarni hal etish</h1>
            <p>Ta’lim sohasidagi nizolar qonunchilikda belgilangan tartibda hal etiladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>71-modda. Ta’lim to‘g‘risidagi qonunchilikni buzganlik uchun javobgarlik</h1>
            <p>Ta’lim to‘g‘risidagi qonunchilikni buzganlikda aybdor shaxslar belgilangan tartibda javobgar bo‘ladi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>72-modda. O‘zbekiston Respublikasining ayrim qonun hujjatlarini o‘z kuchini yo‘qotgan deb topish</h1>
            <p>Quyidagilar o‘z kuchini yo‘qotgan deb hisoblansin:
<br />
1) O‘zbekiston Respublikasining 1997-yil 29-avgustda qabul qilingan “Kadrlar tayyorlash milliy dasturi to‘g‘risida”gi 463-I-sonli Qonuni (O‘zbekiston Respublikasi Oliy Majlisining Axborotnomasi, 1997-yil, № 11-12, 295-modda);
<br />
2) O‘zbekiston Respublikasining 1997-yil 29-avgustda qabul qilingan “Ta’lim to‘g‘risida”gi 464-I-sonli Qonuni (O‘zbekiston Respublikasi Oliy Majlisining Axborotnomasi, 1997-yil, № 9, 225-modda);
<br />
3) O‘zbekiston Respublikasi Oliy Majlisining 1997-yil 29-avgustdagi 465-I-sonli “O‘zbekiston Respublikasining “Ta’lim to‘g‘risida”gi Qonuni kuchga kirish tartibi to‘g‘risida”gi Qarori (O‘zbekiston Respublikasi Oliy Majlisining Axborotnomasi, 1997-yil, № 9, 226-modda);
<br />
4) O‘zbekiston Respublikasining 2007-yil 9-aprelda qabul qilingan “Kadrlar tayyorlash milliy dasturiga o‘zgartish kiritish to‘g‘risida”gi O‘RQ-87-sonli Qonunining (O‘zbekiston Respublikasi Oliy Majlisi palatalarining Axborotnomasi, 2007-yil, № 4, 160-modda) 1-moddasi;
<br />
5) O‘zbekiston Respublikasining 2013-yil 7-oktabrda qabul qilingan “O‘zbekiston Respublikasining ayrim qonun hujjatlariga o‘zgartish va qo‘shimchalar kiritish, shuningdek ayrim qonun hujjatlarini o‘z kuchini yo‘qotgan deb topish to‘g‘risida”gi O‘RQ-355-sonli Qonunining (O‘zbekiston Respublikasi Oliy Majlisi palatalarining Axborotnomasi, 2013-yil, № 10, 263-modda) 15 va 16-moddalari;
<br />
6) O‘zbekiston Respublikasining 2018-yil 3-yanvarda qabul qilingan “Ayrim davlat organlari faoliyati takomillashtirilishi, shuningdek fuqarolarning huquqlari va erkinliklarini himoya qilish kafolatlarini ta’minlashga doir qo‘shimcha chora-tadbirlar qabul qilinishi munosabati bilan O‘zbekiston Respublikasining ayrim qonun hujjatlariga o‘zgartish va qo‘shimchalar kiritish to‘g‘risida”gi O‘RQ-456-sonli Qonunining (O‘zbekiston Respublikasi Oliy Majlisi palatalarining Axborotnomasi, 2018-yil, № 1, 1-modda) 14 va 15-moddalari;
<br />
7) O‘zbekiston Respublikasining 2018-yil 18-aprelda qabul qilingan “O‘zbekiston Respublikasining ayrim qonun hujjatlariga o‘zgartish va qo‘shimchalar kiritish to‘g‘risida”gi O‘RQ-476-sonli Qonunining (O‘zbekiston Respublikasi Oliy Majlisi palatalarining Axborotnomasi, 2018-yil, № 4, 224-modda) 26-moddasi.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>73-modda. Ushbu Qonunning ijrosini, yetkazilishini, mohiyati va ahamiyati tushuntirilishini ta’minlash</h1>
            <p>O‘zbekiston Respublikasi Adliya vazirligi, O‘zbekiston Respublikasi Oliy va o‘rta maxsus ta’lim vazirligi, O‘zbekiston Respublikasi Xalq ta’limi vazirligi, O‘zbekiston Respublikasi Maktabgacha ta’lim vazirligi hamda boshqa manfaatdor vazirliklar, davlat qo‘mitalari, idoralar va tashkilotlar ushbu Qonunning ijrosini, ijrochilarga yetkazilishini hamda mohiyati va ahamiyati aholi o‘rtasida tushuntirilishini ta’minlasin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>74-modda. Qonunchilikni ushbu Qonunga muvofiqlashtirish</h1>
            <p>O‘zbekiston Respublikasi Vazirlar Mahkamasi:

hukumat qarorlarini ushbu Qonunga muvofiqlashtirsin;

davlat boshqaruvi organlari ushbu Qonunga zid bo‘lgan o‘z normativ-huquqiy hujjatlarini qayta ko‘rib chiqishlari va bekor qilishlarini ta’minlasin.</p>
          </div>
          <div>
            <h1 className='text-[20px] font-semibold text-[red] p-5'>75-modda. Ushbu Qonunning kuchga kirishi</h1>
            <p>Ushbu Qonun rasmiy e’lon qilingan kundan e’tiboran kuchga kiradi.</p>
            <div className='flex justify-between items-center mt-5 font-black'>
              <p className='text-center'>Toshkent sh., <br />
2020-yil 23-sentabr,
<br />
O‘RQ-637-son</p>
              <p>O‘zbekiston Respublikasining Prezidenti Sh. MIRZIYOYEV</p>
            </div>
          </div>
        </>
      )
    },
  ];

  const [activeTab, setActiveTab] = useState(1);

  const changeTab = (tabNumber) => {
    setActiveTab(tabNumber);
  };

  return (
    <div className="flex flex-col min-h-screen bg-white">
      <Header />
      <Navbar />
      <main className="w-full max-w-7xl mx-auto px-2 sm:px-4 md:px-8 py-4 md:py-8 flex-1 flex flex-col">
        <div className="text-center mb-6">
          <p className="text-lg sm:text-xl md:text-2xl font-bold text-sky-600">O‘ZBEKISTON RESPUBLIKASINING QONUNI</p>
          <p className="text-sm sm:text-base md:text-lg">TA’LIM TO‘G‘RISIDA</p>
        </div>
        <div className="flex-1 flex flex-col md:flex-row gap-4 md:gap-8">
          <div className="w-full">
            <Tabs tabs={tabs} activeTab={activeTab} onChangeTab={changeTab} />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Talim_togrisida_qonun;