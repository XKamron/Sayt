import React from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const columns = [
  {
    id: 1,
    title: '1. O‘zbekiston Respublikasining Mehnat Kodeksi',
    file: '/files/Mehnat_Kodeksi_yangi.pdf',
  },
  {
    id: 2,
    title: '2. O‘zbekiston Respublikasining “Та‘lim to‘g‘risida”gi qonuni',
    file: '/talim_togrisida_qonun',
  },
  {
    id: 3,
    title: '3. O‘zbekiston Respublikasining “Aholini ish bilan ta’minlash to‘g‘risida”gi qonuni',
    file: '/aholini_ish_bilan_taminlash',
  },
  {
    id: 4,
    title: '4. O‘zbekiston Respublikasining “Bola huquqlarining kafolatlari to‘g‘risida”gi qonuni',
    file: '/bola_huquqlari',
  },
  {
    id: 5,
    title: '5. O‘zbekiston Respublikasining “Jismoniy va yuridik shaxslarning murojaatlari to‘g‘risida”gi qonuni',
    file: '/jismoniy_yuridik_shaxs',
  },
    {
    id: 6,
    title: '6. O‘zbekiston Respublikasining “Kasaba uyushmalari to‘g‘risida”gi qonuni',
    file: '/kasaba_uyushmasi',
  },
    {
    id: 7,
    title: '7. O‘zbekiston Respublikasining “Korrupsiyaga qarshi kurashish to‘g‘risida”gi qonuni',
    file: '/korrupsiyaga_qarshi',
  },
    {
    id: 8,
    title: '8. O‘zbekiston Respublikasining “Madaniy faoliyat va madaniyat tashkilotlari to‘g‘risida”gi qonuni',
    file: '/madaniy_faoliyat',
  },
    {
    id: 9,
    title: '9. O‘zbekiston Respublikasining “Mehnatni muhofaza qilish to‘g‘risida”gi qonuni',
    file: '/mehnat_muhofaza',
  },
    {
    id: 10,
    title: '10. O‘zbekiston Respublikasining “Nogironligi bo‘lgan shaxslarning huquqlari to‘g‘risida”gi qonuni',
    file: '/nogironligi_b_l_shaxs',
  },
  {
    id: 11,
    title: '11. O‘zbekiston Respublikasining “Shaxsga doir ma’lumotlar to‘g‘risida”gi qonuni',
    file: '/shaxsga_doir',
  },
  {
    id: 12,
    title: '12. O‘zbekiston Respublikasining “Yoshlarga oid davlat siyosati to‘g‘risida”gi qonuni',
    file: '/yoshlargaOid',
  },
];
const Kodeks = () => (
  <div className="min-h-screen flex flex-col bg-[#F8FCFF]">
    <Header />
    <Navbar />
    <main className="flex-1 px-4 md:px-16 py-8">
      <h1 className="text-sky-900 text-2xl md:text-3xl font-semibold text-center mb-8">
        O‘zbekiston Respublikasi Kodeks va Qonunlari
      </h1>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {columns.map((column) => {
          // Check if it's a PDF file or a React route
          const isPDF = column.file.includes('.pdf');
          
          if (isPDF) {
            return (
              <a
                key={column.id}
                href={column.file}
                download
                className="flex flex-col justify-between bg-white shadow-md rounded-xl p-6 hover:shadow-lg transition duration-200 text-sky-900 font-bold text-lg md:text-xl mb-4 hover:bg-blue-50"
              >
                {column.title}
              </a>
            );
          } else if (column.file) {
            return (
              <Link
                key={column.id}
                to={column.file}
                className="flex flex-col justify-between bg-white shadow-md rounded-xl p-6 hover:shadow-lg transition duration-200 text-sky-900 font-bold text-lg md:text-xl mb-4 hover:bg-blue-50"
              >
                {column.title}
              </Link>
            );
          } else {
            return (
              <div
                key={column.id}
                className="flex flex-col justify-between bg-gray-200 shadow-md rounded-xl p-6 text-gray-500 font-bold text-lg md:text-xl mb-4 cursor-not-allowed"
              >
                {column.title}
              </div>
            );
          }
        })}
      </div>
    </main>
    <Footer />
  </div>
);

export default Kodeks;