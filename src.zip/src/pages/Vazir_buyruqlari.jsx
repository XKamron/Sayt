import React from 'react';
import Header from '../components/Header';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const columns = [
  {
    id: 1,
    title: 'O‘zbekiston Respublikasi Madaniyat vazirining 2018-yil 26-yanvardagi “Bolalar musiqa va san’at maktablarida baxshichilik san’ati yo‘nalishi bo‘yicha o‘quv rejasi hamda namunaviy o‘quv dasturini tasdiqlash to‘g‘risida” 34-son buyrug‘i',
    file: '/files/MV_34_son_ buyruq_26_01_2018.pdf',
  },
  {
    id: 2,
    title: 'O‘zbekiston Respublikasi Madaniyat vazirining 2019-yil 20-martdagi “Madaniyat vazirining 2018-yil 25-dekabrdagi buyrug‘iga qo‘shimcha va o‘zgartirishlar kiritish to‘g‘risida” 188-son buyrug‘i',
    file: '/files/MV_188_son_ buyruq_20_03_2019.pdf',
  },
  {
    id: 3,
    title: 'O‘zbekiston Respublikasi Madaniyat vazirining 2019-yil 22-apreldagi “Xorijiy mamlakatlariga xizmat safarlariga borishni tartibga solish to‘g‘risida” 245-son buyrug‘i',
    file: '/files/MV_245_son_buyruq.pdf',
  },
  {
    id: 4,
    title: 'O‘zbekiston Respublikasi Madaniyat vazirining 2019-yil 12-avgustadagi “Bolalar musiqa va san’at maktablari faoliyatiga oid me’yoriy hujjatlar namunamalarini tasdiqlash to‘g‘risida” 478-buyrug‘i',
    file: '/files/MV_478_son_buyruq_12_08_2019.pdf',
  },
  {
    id: 5,
    title: 'O‘zbekiston Respublikasi Madaniyat vazirining 2019-yil 30-dekabrdagi “Bolalar musiqa va san’at maktablarining ta‘lim yo‘nalishlari bo‘yicha o‘quv rejalarini hamda o‘quv rejalariga tushuntirishlarini tasdiqlash to‘g‘risida” 766-son buyrug‘i',
    file: '/files/MV_766_son_buyruq_uquv_reja.pdf',
  },
  {
    id: 6,
    title: 'O‘zbekiston Respublikasi Madaniyat vazirining 2021-yil 21-apreldagi “O‘zbekiston Respublikasi Madaniyat vazirligi tasarrufidagi bolalar musiqa va san‘at maktablari, ixtisoslashtirilgan san‘at va madaniyat maktablari, maktab-internatlari hamda Karim Zaripov nomidagi Respublika estrada va sirk kolleji, Respublika musiqa va san’at kollejlarining ikkinchi malaka toifasiga talabgor pedagog kaddrlarni attestasiyadan o‘tkazish to‘g‘risida” 183-son buyrug‘i',
    file: '/files/MV_183_son_buyruq.pdf',
  },
  {
    id: 7,
    title: 'O‘zbekiston Respublikasi Madaniyat vazirining 2019-yil 20-dekabrdagi “Bolalar musiqa va san’at maktablarida o‘quvchilar bilimining davlat talablariga mosligi arajasini aniqlash mexanizmini joriy etish hamda monitoring olib borish to‘g‘risida” 751-son buyrug‘i',
    file: '/files/MV_751_son_buyruq.pdf',
  },
  {
    id: 8,
    title: 'O‘zbekiston Respublikasi Madaniyat vazirining 2022-yil 2-fevraldagi “Xodimlarning lavozim nomenklaturasini tasdiqlash to‘g‘risida” 38-son buyrug‘i',
    file: '/files/MV_38_son_buyruq_02_02_2022.pdf',
  },
  {
    id: 9,
    title: 'O‘zbekiston Respublikasi Madaniyat vazirining 2022-yil 20-apreldagi “Davlat ta’lim talablarini tasdiqlash to’g’risida” 121-son buyrug‘i',
    file: '/files/MV_121_son_buyruq.pdf',
  },
  {
    id: 10,
    title: 'O‘zbekiston Respublikasi Madaniyat vazirining 2022-yil 20-sentabrdagi “Yosh mutaxassislarni tanlashga oid hujjatlarni tasdiqlash to‘g‘risida” 378-son buyrug‘i',
    file: '/files/MV_378.pdf',
  },
  {
    id: 11,
    title: 'O‘zbekiston Respublikasi Madaniyat vazirining 2023-yil 28-iyuldagi “O‘zbekiston Respublikasi Prezidenti Farmoni ijrosini ta\'minlash to‘g‘risida” 2-son buyrug‘i',
    file: '/files/MV_2_28_07.pdf',
  },
  {
    id: 12,
    title: 'O‘zbekiston Respublikasi Vazirlar Mahkamasi huzuridagi ta’lim sifatini nazorat qilish Davlat inspeksiyasi va O‘zbekiston Respublikasi Madaniyat vazirligining "O‘zbekiston Respublikasi Madaniyat vazirligi tizimidagi ta’lim muassasalari pedagog kadrlarining o‘quv fanidan malaka sinovlarini tashkil etish to‘g‘risida" qo‘shma qarori',
    file: '/files/MV_Qushma_qaror.pdf',
  },
    {
    id: 13,
    title: 'O‘zbеkistоn Rеspublikаsi Madaniyat vazirining 2024-yil 24-yanvardagi “Bolalar musiqa va san’at maktablari direktorlari faoliyatini muvofiqlashtiruvchi kengash faoliyatini takomillashtirish to‘g‘risida”gi 39-son buyrug‘i',
    file: '/files/MV_39_24_01_2024.pdf',
  },
    {
    id: 14,
    title: 'O‘zbеkistоn Rеspublikаsidа Bоlаlаrning bоshlаng‘ich sаn’аt tа’limi Kоnsеpsiyasi',
    file: '/files/MV_Boshlangich_sanat_talim_konsepsiya.pdf',
  },
];

const Vazir_buyruqlari = () => (
  <div className="min-h-screen flex flex-col bg-[#F8FCFF]">
    <Header />
    <Navbar />
    <main className="flex-1 px-4 md:px-16 py-8">
      <h1 className="text-sky-900 text-2xl md:text-3xl font-semibold text-center mb-8">
        O‘zbekiston Respublikasi Madaniyat vaziri buyruqlari
      </h1>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {columns.map((column) => (
          <a
            key={column.id}
            href={column.file}
            download
            className="flex flex-col justify-between bg-white shadow-md rounded-xl p-6 hover:shadow-lg transition duration-200 text-sky-900 font-bold text-lg md:text-xl mb-4 hover:bg-blue-50"
          >
            {column.title}
          </a>
        ))}
      </div>
    </main>
    <Footer />
  </div>
);

export default Vazir_buyruqlari;