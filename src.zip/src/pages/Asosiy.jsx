import React from "react";
import { motion } from "framer-motion";
import Particles from "react-tsparticles";
import { loadFull } from "tsparticles";
import {
  FaCalendarAlt,
  FaPhone,
  FaEnvelope,
  FaClock,
  FaUsers,
  FaGraduationCap,
} from "react-icons/fa";

import Navbar from "../components/Navbar";
import Header from "../components/Header";
import Footer from "../components/Footer";

// === Particles Init ===
const particlesInit = async (main) => {
  await loadFull(main);
};

// === Animation Variants ===
const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0 },
};
const scaleIn = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: { opacity: 1, scale: 1 },
};

// === School Data ===
const schoolInfo = {
  general: {
    title: "Umumiy ma'lumotlar",
    icon: FaGraduationCap,
    color: "bg-blue-50 border-blue-200",
    items: [
      { label: "Tashkil etilgan yil", value: "1970-yil", icon: FaCalendarAlt },
      {
        label: "To'liq nomi",
        value:
          "Toshkent shahar madaniyat boshqarmasi tasarrufidagi Chilonzor tumani To'xtasin Jalilov nomidagi 6-son bolalar musiqa va san'at maktabi",
      },
      { label: "Qisqartirilgan nomi", value: "Chilonzor tumani 6-son BMSM" },
      { label: "Muassisi", value: "Toshkent shahar hokimligi" },
      { label: "Yuqori organi", value: "Toshkent shahar madaniyat boshqarmasi" },
      { label: "Ta'lim turi", value: "Maktabdan tashqari ta'lim muassasasi" },
      { label: "Faoliyati yo'nalishi", value: "Musiqa va san'at" },
    ],
  },
  contact: {
    title: "Aloqa ma'lumotlari",
    icon: FaPhone,
    color: "bg-red-50 border-red-200",
    items: [
      { label: "Aloqa telefoni", value: "+998 71 277-00-85", icon: FaPhone },
      { label: "Elektron pochta", value: "6bmsmtoshkent.uz@umail.uz", icon: FaEnvelope },
    ],
  },
  schedule: {
    title: "Ish tartibi",
    icon: FaClock,
    color: "bg-orange-50 border-orange-200",
    items: [
      {
        label: "Ma'muriyat ish kuni",
        value: "9:00 - 18:00 (tushlik 13:00 - 14:00)",
        icon: FaClock,
      },
      {
        label: "O'quv jarayoni",
        value: "8:00 - 20:00, 6 kunlik o'quv haftasi",
      },
    ],
  },
};

const directions = [
  { name: "Fortepiano", description: "Klassik va zamonaviy musiqa asarlari ijrosi", students: 45 },
  { name: "Skripka", description: "Torli cholg'u asboblari ijrosi", students: 32 },
  { name: "Vokal", description: "Xalq va estrada qo'shiqlari ijrosi", students: 28 },
  { name: "Xalq cholg'ulari", description: "Milliy cholg'u asboblari ijrosi", students: 38 },
  { name: "Raqs", description: "Xalq va zamonaviy raqslar", students: 55 },
  { name: "Tasviriy san'at", description: "Rasm va amaliy san'at", students: 42 },
];

// === InfoCard ===
const InfoCard = ({ item, categoryColor, idx }) => {
  const IconComponent = item.icon;
  return (
    <motion.div
      className={`bg-white rounded-xl shadow-sm border-2 ${categoryColor} p-4 sm:p-6 hover:shadow-lg`}
      variants={fadeUp}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: idx * 0.1 }}
      whileHover={{ y: -4 }}
    >
      <div className="flex items-start space-x-3 font-[Poppins]">
        {IconComponent && (
          <div className="flex-shrink-0 mt-1">
            <IconComponent className="text-sky-600 text-lg" />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <dt className="text-sm font-semibold text-sky-900 mb-2">{item.label}</dt>
          <dd className="text-gray-700 text-sm sm:text-base break-words">{item.value}</dd>
        </div>
      </div>
    </motion.div>
  );
};

// === CategorySection ===
const CategorySection = ({ data }) => {
  const IconComponent = data.icon;
  return (
    <section className="mb-12">
      <motion.div
        className="flex items-center space-x-3 mb-6"
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
      >
        <div className={`p-3 rounded-full ${data.color}`}>
          <IconComponent className="text-xl text-sky-700" />
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-sky-900 font-[Playfair Display]">
          {data.title}
        </h2>
      </motion.div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6">
        {data.items.map((item, idx) => (
          <InfoCard key={idx} item={item} categoryColor={data.color} idx={idx} />
        ))}
      </div>
    </section>
  );
};

// === Floating Music Notes ===
const MusicNotes = () => {
  const notes = ["🎵", "🎶", "🎼"];
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-10">
      {Array.from({ length: 12 }).map((_, idx) => {
        const randomLeft = Math.random() * 100;
        const randomDelay = Math.random() * 6;
        const randomDuration = 8 + Math.random() * 6;
        const horizontalSwing = 15 + Math.random() * 15;
        const rotationAngle = 10 + Math.random() * 20;

        return (
          <motion.div
            key={idx}
            className="absolute text-white text-2xl sm:text-3xl opacity-40"
            style={{ left: `${randomLeft}%` }}
            initial={{ y: "100vh", opacity: 0 }}
            animate={{
              y: "-10vh",
              opacity: [0, 0.5, 0],
              x: [0, horizontalSwing, -horizontalSwing, 0],
              rotate: [0, rotationAngle, -rotationAngle, 0],
            }}
            transition={{
              duration: randomDuration,
              repeat: Infinity,
              delay: randomDelay,
              ease: "easeInOut",
            }}
          >
            {notes[Math.floor(Math.random() * notes.length)]}
          </motion.div>
        );
      })}
    </div>
  );
};

// === Hero Section ===
const HeroSection = () => (
  <section className="relative text-white py-20 text-center overflow-hidden bg-gradient-to-br from-sky-600 via-blue-700 to-sky-900">
    <Particles
      className="absolute top-0 left-0 w-full h-full z-0"
      init={particlesInit}
      options={{
        particles: {
          number: { value: 50 },
          color: { value: "#ffffff" },
          opacity: { value: 0.2 },
          size: { value: 2 },
          move: { enable: true, speed: 0.4 },
        },
        background: { color: { value: "transparent" } },
      }}
    />
    <MusicNotes />
    <motion.div
      className="max-w-4xl mx-auto px-4 relative z-20"
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
    >
      <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 font-[Playfair Display]">
        To'xtasin Jalilov nomidagi 6-son BMSM
      </h1>
      <p className="text-lg sm:text-xl text-sky-100 max-w-3xl mx-auto leading-relaxed font-[Poppins]">
        1970-yildan buyon musiqaga va san’atga mehr uyg‘otayotgan maktab
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-4 text-sm sm:text-base font-[Poppins]">
        <div className="bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
          <FaCalendarAlt className="inline mr-2" />
          50+ yillik tajriba
        </div>
        <div className="bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
          <FaUsers className="inline mr-2" />
          240+ o‘quvchi
        </div>
        <div className="bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
          <FaGraduationCap className="inline mr-2" />
          6 ta yo‘nalish
        </div>
      </div>
    </motion.div>
  </section>
);

const Asosiy = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 font-[Poppins]">
      <Header />
      <Navbar />

      <HeroSection />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 relative z-10">
        {Object.entries(schoolInfo).map(([key, data]) => (
          <CategorySection key={key} data={data} />
        ))}

        <motion.section
          className="mb-12"
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <div className="text-center mb-8">
            <h2 className="text-2xl sm:text-3xl font-bold text-sky-900 mb-4 font-[Playfair Display]">
              Mavjud yo'nalishlar
            </h2>
            <p className="text-gray-600 text-sm sm:text-base max-w-2xl mx-auto">
              Maktabimizda 6 ta asosiy yo'nalish bo'yicha ta'lim beriladi
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {directions.map((direction, idx) => (
              <motion.div
                key={idx}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-lg"
                variants={scaleIn}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: idx * 0.1 }}
                whileHover={{ y: -4 }}
              >
                <div className="text-center font-[Poppins]">
                  <h3 className="text-lg font-bold text-sky-900 mb-2">{direction.name}</h3>
                  <p className="text-gray-600 text-sm mb-4 leading-relaxed">{direction.description}</p>
                  <div className="inline-flex items-center bg-sky-100 text-sky-800 px-3 py-1 rounded-full text-sm font-medium">
                    <FaUsers className="mr-2 text-xs" />
                    {direction.students} o'quvchi
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.section>
      </main>

      <Footer />
    </div>
  );
};

export default Asosiy;
