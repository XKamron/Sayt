import React from 'react';
import Header from '../components/Header';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Numbers from '../components/Numbers';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { MdArrowForwardIos } from "react-icons/md";
import {
  leftSwipe,
  rightSwipe,
  gradientCarousel,
  news_1,
  news_2,
  news_3,
  xareografiya,
  vokal,
  uzbek,
  tasviriy,
  nazariya,
  fortepiano,
} from '../img';
import '../index.css';

const Home = () => {
  const SlickArrowLeft = ({ currentSlide, slideCount, ...props }) => (
    <img
      src={leftSwipe}
      alt="prevArrow"
      {...props}
      className="l-swipe w-8 sm:w-10 md:w-12 lg:w-16 xl:w-12 ml-[-10px] md:ml-[-12px] xl:ml-0"
    />
  );

  const SlickArrowRight = ({ currentSlide, slideCount, ...props }) => (
    <img
      src={rightSwipe}
      alt="nextArrow"
      {...props}
      className="r-swipe w-8 sm:w-10 md:w-12 lg:w-16 xl:w-12 mr-[-10px] md:mr-[-12px] xl:mr-0"
    />
  );

  const settings = {
    dots: false,
    fade: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    prevArrow: <SlickArrowLeft />,
    nextArrow: <SlickArrowRight />,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: false,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <div>
      <Header />
      <Navbar />

      {/* Carousel */}
      <div className="relative">
        <Slider {...settings} className="max-w-full">
          <div className="relative">
            <div className="absolute z-10 mx-6 sm:mx-8 md:mx-10 lg:mx-16 xl:mx-20 my-8 sm:my-12 md:my-16 lg:my-12 xl:my-20">
              <p className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl text-white font-bold w-4/5 sm:w-3/4 md:w-2/3 leading-tight">
                {/* Content here */}
              </p>
            </div>
            <img src={gradientCarousel} alt="carousel-img" className="absolute w-full" />
            <img src={gradientCarousel} alt="carousel-img" className="w-full" />
          </div>
          {/* Additional carousel slides */}
          <div>
            <img src={gradientCarousel} alt="carousel-img" className="w-full" />
          </div>
          <div>
            <img src={gradientCarousel} alt="carousel-img" className="w-full" />
          </div>
          <div>
            <img src={gradientCarousel} alt="carousel-img" className="w-full" />
          </div>
        </Slider>
      </div>

      {/* Latest news */}
      <div className="mx-2 sm:mx-6 lg:mx-16">
        <div className="flex flex-col md:flex-row justify-between items-center py-6 md:py-10 gap-4">
          <p className="text-sky-900 text-xl sm:text-2xl md:text-3xl font-bold mb-2 md:mb-0">
            SO’NGGI YANGILIKLAR
          </p>
          <a
            href="#"
            className="flex items-center text-[#76B1E8] text-base sm:text-lg md:text-xl font-medium"
          >
            BARCHASINI KO’RISH
            <MdArrowForwardIos className="ml-2" />
          </a>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Левая часть: картинки */}
          <div className="space-y-6">
            <div className="relative rounded-lg overflow-hidden">
              <img src={news_1} alt="news_1" className="w-full h-48 sm:h-64 object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent rounded-lg"></div>
              <div className="absolute bottom-0 left-0 p-4 text-white">
                <span className="text-xs sm:text-sm">2023-11-12</span>
                <p className="text-sm sm:text-base font-semibold">
                  Shofirkon: Quyi Chuqurakda bir kunda 500 tup manzarali.....
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="relative rounded-lg overflow-hidden">
                <img src={news_2} alt="news_2" className="w-full h-40 sm:h-48 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent rounded-lg"></div>
                <div className="absolute bottom-0 left-0 p-4 text-white">
                  <span className="text-xs sm:text-sm">2023-11-12</span>
                  <p className="text-sm sm:text-base font-semibold">
                    Shofirkon: Quyi Chuqurakda bir kunda 500 tup manzarali.....
                  </p>
                </div>
              </div>
              <div className="relative rounded-lg overflow-hidden">
                <img src={news_3} alt="news_3" className="w-full h-40 sm:h-48 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent rounded-lg"></div>
                <div className="absolute bottom-0 left-0 p-4 text-white">
                  <span className="text-xs sm:text-sm">2023-11-12</span>
                  <p className="text-sm sm:text-base font-semibold">
                    Shofirkon: Quyi Chuqurakda bir kunda 500 tup manzarali.....
                  </p>
                </div>
              </div>
            </div>
          </div>
          {/* Правая часть: текстовые карточки */}
          <div className="flex flex-col gap-4">
            <div className="bg-[#FFF6EB] rounded-2xl p-4 sm:p-5">
              <span className="text-[#3A80EC] text-xs sm:text-sm lg:text-base">
                2023-11-12
              </span>
              <p className="text-blue-950 text-lg sm:text-xl lg:text-2xl font-semibold">
                “Ayollar dunyo boyligi va muhabbati” bayram tadbiri tashkil qilindi
              </p>
            </div>
            <div className="bg-[#FFF6EB] rounded-2xl p-4 sm:p-5">
              <span className="text-[#3A80EC] text-xs sm:text-sm lg:text-base">
                2023-11-12
              </span>
              <p className="text-blue-950 text-lg sm:text-xl lg:text-2xl font-semibold">
                “Ayollar dunyo boyligi va muhabbati” bayram tadbiri tashkil qilindi
              </p>
            </div>
            <div className="bg-[#FFF6EB] rounded-2xl p-4 sm:p-5">
              <span className="text-[#3A80EC] text-xs sm:text-sm lg:text-base">
                2023-11-12
              </span>
              <p className="text-blue-950 text-lg sm:text-xl lg:text-2xl font-semibold">
                “Ayollar dunyo boyligi va muhabbati” bayram tadbiri tashkil qilindi
              </p>
            </div>
            <div className="bg-[#FFF6EB] rounded-2xl p-4 sm:p-5">
              <span className="text-[#3A80EC] text-xs sm:text-sm lg:text-base">
                2023-11-12
              </span>
              <p className="text-blue-950 text-lg sm:text-xl lg:text-2xl font-semibold">
                “Ayollar dunyo boyligi va muhabbati” bayram tadbiri tashkil qilindi
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bo'limlar */}
      <div>
        <div className="mx-4 sm:mx-6 lg:mx-16 my-8 sm:my-10">
          <p className="text-sky-900 text-center text-lg sm:text-xl md:text-2xl lg:text-3xl font-bold mb-4 sm:mb-5">
            Maktabda faoliyat ko‘rsatayotgan bo‘limlar
          </p>
          <div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4 sm:gap-6 justify-items-center items-center">
              {/* Пример карточки */}
              <div className="flex flex-col items-center bg-white rounded-xl shadow-md p-2 w-full h-40 justify-center">
                <img src={xareografiya} alt="Xoreografiya" className="object-contain h-20 mb-2" />
                <span className="text-center text-sm sm:text-base font-medium text-sky-900">Xoreografiya</span>
              </div>
              <div className="flex flex-col items-center bg-white rounded-xl shadow-md p-2 w-full h-40 justify-center">
                <img src={uzbek} alt="O'zbek cholg'usi" className="object-contain h-20 mb-2" />
                <span className="text-center text-sm sm:text-base font-medium text-sky-900">Xalq cholg‘ulari bo‘limi</span>
              </div>
              <div className="flex flex-col items-center bg-white rounded-xl shadow-md p-2 w-full h-40 justify-center">
                <img src={vokal} alt="Vokal" className="object-contain h-20 mb-2" />
                <span className="text-center text-sm sm:text-base font-medium text-sky-900">Estrada cholg‘u ijrochiligi va xonandaligi bo‘limi</span>
              </div>
              <div className="flex flex-col items-center bg-white rounded-xl shadow-md p-2 w-full h-40 justify-center">
                <img src={tasviriy} alt="Tasviriy san'at" className="object-contain h-20 mb-2" />
                <span className="text-center text-sm sm:text-base font-medium text-sky-900">Tasviriy san’at bo‘limi</span>
              </div>
              <div className="flex flex-col items-center bg-white rounded-xl shadow-md p-2 w-full h-40 justify-center">
                <img src={nazariya} alt="Nazariya" className="object-contain h-20 mb-2" />
                <span className="text-center text-sm sm:text-base font-medium text-sky-900">Musiqa nazariyasi va xor ijrochiligi bo‘limi</span>
              </div>
              <div className="flex flex-col items-center bg-white rounded-xl shadow-md p-2 w-full h-40 justify-center">
                <img src={fortepiano} alt="Fortepiano" className="object-contain h-20 mb-2" />
                <span className="text-center text-sm sm:text-base font-medium text-sky-900">Fortepiano, torli va damli cholg‘ular bo‘limi</span>
              </div>
            </div>
          </div>
        </div>
        
      </div>

    <div>
        <Numbers />
    </div>

      <Footer />
    </div>
  );
};

export default Home;
