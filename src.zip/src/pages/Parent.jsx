import React from 'react';
import { FaUsers, FaGavel, FaClipboardList, FaFileAlt, FaMoneyBillWave, FaChild, FaHeart, FaHandshake, FaDownload, FaInfoCircle } from 'react-icons/fa';
import Navbar from '../components/Navbar';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Parent = () => {
  const rightsData = [
    { icon: FaGavel, text: "Bolalar musiqa va san'at maktabi rahbariyatidan farzandi uchun mazkur maktabning ustaviga muvofiq zarur shart-sharoitlar yaratilishini talab qilish" },
    { icon: FaHeart, text: "Bola shaxsiga hurmat bilan munosabatda bo'lishni talab qilish" },
    { icon: FaHandshake, text: "Jamoatchilik asosida bolalar musiqa va san'at maktabining ish faoliyatida ishtirok etish" },
    { icon: FaInfoCircle, text: "Qonun hujjatlarida belgilangan boshqa huquqlar" }
  ];

  const responsibilitiesData = [
    { icon: FaHeart, text: "Farzandining jismoniy va ruhiy sog'lom bo'lishi uchun g'amxo'rlik qilish" },
    { icon: FaChild, text: "Bolaning qadr-qimmatiga hurmat bilan qarash, uni mehnatsevarlik, ezgulik, vatanparvarlik ruhida tarbiyalash" },
    { icon: FaGavel, text: "Farzandida qonunlarga itoatkorlik, inson huquqlari va erkinliklariga hurmat tuyg'usini tarbiyalash" },
    { icon: FaClipboardList, text: "Farzandiga o'quv mashg'ulotlarida ishtirok etishi uchun zarur shart-sharoitlar yaratish" },
    { icon: FaUsers, text: "Farzandining ta'lim olishiga ko'maklashish va uzrli sabablarsiz o'quv mashg'ulotlariga muntazam qatnashishini ta'minlash" },
    { icon: FaMoneyBillWave, text: "O'qish uchun to'lovni o'z vaqtida amalga oshirish" }
  ];

  const InfoCard = ({ icon: Icon, children, color = "bg-white" }) => (
    <div className={`${color} rounded-xl shadow-sm border border-gray-200 p-4 sm:p-6 hover:shadow-md transition-all duration-300 hover:-translate-y-1`}>
      <div className="flex items-start space-x-3">
        {Icon && (
          <div className="flex-shrink-0 mt-1">
            <div className="w-8 h-8 bg-sky-100 rounded-full flex items-center justify-center">
              <Icon className="text-sky-600 text-sm" />
            </div>
          </div>
        )}
        <div className="flex-1">{children}</div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50">
      <Header />
      <Navbar />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-orange-600 to-red-600 text-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 leading-tight">
            Ota-onalar, sizlar uchun!
          </h1>
          <p className="text-lg sm:text-xl text-orange-100 max-w-4xl mx-auto leading-relaxed">
            Farzandingizning musiqa va san'at sohasidagi rivojlanishi uchun muhim ma'lumotlar
          </p>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Introduction Section */}
        <section className="mb-12">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sm:p-8">
            <div className="flex items-start space-x-4 mb-6">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                <FaInfoCircle className="text-orange-600 text-xl" />
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4">Muhim ma'lumot</h2>
                <p className="text-gray-700 leading-relaxed text-sm sm:text-base">
                  Bolaning musiqa va san'at maktabiga o'qishga kirishi - oila hayotidagi muhim voqea bo'lib, 
                  bu oila a'zolaridan ushbu voqeaga jiddiy yondashishini talab qiladi. Farzandingizning 
                  o'zlashtirishi bilan qiziqib maktabga kelib tashrif buyurib tursangiz, pedagoglardan olgan 
                  maslahatlarga amal qilib farzandingizga uy vazifalarini bajarishda yordam bersangiz - bu 
                  Sizning farzandingizni kelajakdagi yutuqlariga qo'shgan g'oyat katta ulushingizdir.
                </p>
                <div className="mt-4 p-4 bg-orange-50 rounded-lg">
                  <p className="text-sm text-orange-800">
                    <strong>Eslatma:</strong> Maktabimizda ota-onalar qo'mitasi faoliyat olib boradi. 
                    Maktab pedagoglari tomonidan ota-onalar uchun davra stollari, seminarlar tashkil etilib turiladi.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Rights Section */}
        <section className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">Ota-onalarning huquqlari</h2>
            <p className="text-gray-600 text-sm sm:text-base max-w-2xl mx-auto">
              Maktab Ustaviga muvofiq ota-onalar quyidagi huquqlarga ega
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {rightsData.map((right, idx) => (
              <InfoCard key={idx} icon={right.icon} color="bg-green-50">
                <p className="text-gray-700 text-sm sm:text-base leading-relaxed">{right.text}</p>
              </InfoCard>
            ))}
          </div>
        </section>

        {/* Responsibilities Section */}
        <section className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">Ota-onalarning majburiyatlari</h2>
            <p className="text-gray-600 text-sm sm:text-base max-w-2xl mx-auto">
              Farzandingizning muvaffaqiyatli ta'lim olishi uchun quyidagi majburiyatlarni bajarish zarur
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {responsibilitiesData.map((responsibility, idx) => (
              <InfoCard key={idx} icon={responsibility.icon} color="bg-blue-50">
                <p className="text-gray-700 text-sm sm:text-base leading-relaxed">{responsibility.text}</p>
              </InfoCard>
            ))}
          </div>
        </section>

        {/* Документы для поступления */}
        <section className="px-2 sm:px-4 md:px-8 lg:px-32 py-8">
          <h2 className="text-center text-xl sm:text-2xl font-semibold text-[#00486C] mb-4">
            Bolalar musiqa va san’at maktabiga o‘qishga kirish uchun taqdim etiladigan hujjatlar:
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow p-4">
              <ul className="list-decimal list-inside space-y-1 text-base sm:text-lg">
                <li>ta’lim yo‘nalishi (yo‘nalishlari) ko‘rsatilgan ariza;</li>
                <li>o‘quvchining tug‘ilganlik haqidagi guvohnomasi nusxasi;</li>
                <li>o‘quvchiga belgilangan shaklda berilgan tibbiy ma’lumotnoma;</li>
                <li>3 x 4 o‘lchamli 2 ta fotosurat.</li>
              </ul>
            </div>
            <div className="bg-white rounded-lg shadow p-4">
              <ul className="list-decimal list-inside space-y-1 text-base sm:text-lg">
                <li>ta’lim yo‘nalishi (yo‘nalishlari) ko‘rsatilgan ariza;</li>
                <li>o‘quvchining tug‘ilganlik haqidagi guvohnomasi nusxasi;</li>
                <li>o‘quvchiga belgilangan shaklda berilgan tibbiy ma’lumotnoma;</li>
                <li>3 x 4 o‘lchamli 2 ta fotosurat.</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Образцы заявлений */}
        <section className="px-2 sm:px-4 md:px-8 lg:px-32 py-8">
          <h2 className="text-center text-xl sm:text-2xl font-semibold text-[#00486C] mb-4">
            Ota-onalar tomonidan to‘ldiriladigan arizalar namunalari
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow p-4 space-y-2">
              <p>O‘quvchini o‘qishga qabul qilish to‘g‘risida ariza</p>
              <p>Musiqa cholg‘u asbobi berish to‘g‘risida ariza va tilxat</p>
              <p>O‘quvchini boshqa maktabdan o‘tkazish to‘g‘risida ariza</p>
            </div>
            <div className="bg-white rounded-lg shadow p-4 space-y-2">
              <p>Badal pulidan ozod qilish to‘g‘risida ariza</p>
              <p>Ota-onalar bilan shartnoma</p>
            </div>
          </div>
        </section>

        <div className="px-2 sm:px-4 md:px-8 lg:px-32 py-8">
          <div className="bg-white rounded-lg shadow p-4 mb-8">
            <p className="text-base sm:text-lg">
              Ota-onalar tomonidan bolalarning bolalar musiqa va san’at maktablarida o‘qishi uchun haq to‘lash va undan foydalanish tartibi to‘g‘risida NIZOM<br />
              6-sonli bolalar musiqa va san’at maktabi otа-оnаlаr qo‘mitаsi to‘g‘risidа Nizom
            </p>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <h2 className="text-center text-xl sm:text-2xl font-semibold text-[#00486C] mb-6">
              Bolalarning o‘qishi uchun to‘lanadigan haq miqdori
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-6">
                <div className="bg-[#F0F8FF] rounded-lg p-4 flex flex-col items-center">
                  <p className="text-base sm:text-lg mb-2">Musiqa yo‘nalishi:</p>
                  <h1 className="font-extrabold text-3xl sm:text-4xl text-center text-[#00486C]">100 000 so‘m</h1>
                </div>
                <div className="bg-[#F0F8FF] rounded-lg p-4 flex flex-col items-center">
                  <p className="text-base text-center sm:text-lg mb-2">Bir oiladan 2 yoki undan ortiq farzand o‘qigan taqdirda, har bir farzand uchun:</p>
                  <h1 className="font-extrabold text-3xl sm:text-4xl text-center text-[#00486C]">178 500 so‘m</h1>
                </div>
              </div>
              <div className="flex flex-col gap-6">
                <div className="bg-[#F0F8FF] rounded-lg p-4 flex flex-col items-center">
                  <p className="text-base sm:text-lg mb-2">San’at yo‘nalishi:</p>
                  <h1 className="font-extrabold text-3xl sm:text-4xl text-center text-[#00486C]">100 000 so‘m</h1>
                </div>
                <div className="bg-[#F0F8FF] rounded-lg p-4 flex flex-col items-center">
                  <p className="text-base text-center sm:text-lg mb-2">Bir oiladan 2 yoki undan ortiq farzand o‘qigan taqdirda, har bir farzand uchun:</p>
                  <h1 className="font-extrabold text-3xl sm:text-4xl text-center text-[#00486C]">119 000 so‘m</h1>
                </div>
              </div>
            </div>
          </div>
        </div>

      </main>

      <Footer />
    </div>
  );
};

export default Parent;