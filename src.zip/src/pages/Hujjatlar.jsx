import React from 'react';
import { PiDownloadSimpleBold } from 'react-icons/pi';
import pdfFile from '../files/simon-sinek-start-with-why.pdf';
import Header from '../components/Header';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const Hujjatlar = () => {
  const columns = [
    {
      title:
        'XALQ DEPUTATLARI XORAZM VILOYATI KENGASHINING 71-SESSIYASINI CHAQIRISH TOʻGʻRISIDA...',
      fileName: pdfFile,
      date: '2023-11-16', 
    },
    {
      title:
        'XALQ DEPUTATLARI XORAZM VILOYATI KENGASHINING 71-SESSIYASINI CHAQIRISH TOʻGʻRISIDA...',
      fileName: pdfFile,
      date: '2023-11-16', 
    },
    {
      title:
        'XALQ DEPUTATLARI XORAZM VILOYATI KENGASHINING 71-SESSIYASINI CHAQIRISH TOʻGʻRISIDA...',
      fileName: pdfFile,
      date: '2023-11-16', 
    },
    {
      title:
        'XALQ DEPUTATLARI XORAZM VILOYATI KENGASHINING 71-SESSIYASINI CHAQIRISH TOʻGʻRISIDA...',
      fileName: pdfFile,
      date: '2023-11-16', 
    },
    {
      title:
        'XALQ DEPUTATLARI XORAZM VILOYATI KENGASHINING 71-SESSIYASINI CHAQIRISH TOʻGʻRISIDA...',
      fileName: pdfFile,
      date: '2023-11-16', 
    },
  ];

  return (
    <div>
      <Header />
      <Navbar />

      <div className="mx-[5rem] my-[2rem]">
        <div className="text-sky-900 text-[25px] font-medium font-['Montserrat']">
           <span className=''>Bosh sahifa / ...</span>
        </div>

              {columns.map((column, index) => (
                <div key={index} className="flex justify-between items-center bg-[#BCF5F9] bg-opacity-50 rounded-[15px] px-4 my-8">
                  <div className="block w-full p-4">
                    <p className="text-blue-500 text-sm font-medium font-['Montserrat']">{column.date}</p>
                    <p className="text-sky-900 text-[22px] font-bold font-['Montserrat']">
                  {column.title}
                </p>
                </div>
                <div className="flex items-center">
                <PiDownloadSimpleBold className="ml-1 text-sky-900 text-[2.5rem]" />
                  <a
                    href={column.fileName}
                    download={column.fileName}
                    className="text-sky-900 text-[20px] font-semibold font-['Montserrat'] underline ml-2"
                  >
                    Yuklash
                  </a>
                </div>
                </div>
              ))}
      </div>


        <Footer />
    </div>
  );
};

export default Hujjatlar;
